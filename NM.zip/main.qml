// NM for QField  -  navigation / tracking plugin for line-prep machinery (dozers, slashers, graders, utes)
// A QField port of the NavMini 7.5 rules (Terrex Spatial), simplified from the N25 survey plugin:
//   * Line guidance        - choose a LINE + direction (DIR +/-): station, distance to next station, distance to end of line,
//                            cross track (L/R) with an arrow back to the line, NAV view (line always up) or MAP view (north up)
//   * No-Go / Warning      - NG_* polygon layers = red No-Go zone, WZ_* = orange Warning zone, with the NavMini geofence sounds
//   * Advisories           - point layer with a text field: message pops up when the machine is within the flag distance
//   * Tracking             - machine track logged every N metres and/or N seconds, shown as a red trail on the map
//   * MARK                 - record a feature (code, string no, remarks) as a single point or as a stream every N metres
//   * Machine offset       - in-line correction from the GNSS antenna to the machine reference point (NavMini "Vibe offset")
//   * Position marker      - own symbol (arrow, crosshair, 4WD, ute, truck, tractor, skid steer ...) + bearing line (500 m - 20 km)
//
// STANDALONE: install the zip once (QField > Settings > Plugins), then switch it on / off in the plugin list. Nothing has to be
// added to a project. Track and marks are written to CSV files beside the project (and also to NM_TrackPts / NM_Marks layers if
// the project happens to have them).  Preplot points are auto-detected (station + line fields), NG_* / WZ_* layers are read if present.

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import org.qfield.core
import org.qfield.gui

Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var positioning: iface.positioning()
  property var mapCanvas: iface.mapCanvas()
  readonly property string nmVersion: "NM v1.3"

  // ---- settings (all remembered per project) ----
  property var preplotLayerNames: []
  property string stationField: ""             // blank = auto-detect
  property string lineField: ""
  property string preplotName: ""              // blank = auto-detect
  property string stnUse: ""
  property string lineUse: ""
  property string preplotInfo: ""
  property bool stationHasLinePrefix: false
  property string noGoPrefix: "NG_"
  property string warnPrefix: "WZ_"
  property string trackLayerName: "NM_TrackPts" // track POINTS layer (from NS_AddLayers.py, in NS_Data.gpkg) - optional, used only if the layer exists
  property string marksLayerName: "NM_Marks"   // marks layer (from NS_AddLayers.py, in NS_Data.gpkg) - optional
  property string advLayerName: ""             // advisory point layer (blank = no advisories)
  property string advField: ""                 // advisory text field (blank = first text field after the first column)
  property real advDist: 100                   // advisory flag distance (m)

  property real xTol: 5.0            // on-line corridor: XTrack within this = green screen
  property real aTol: 1.0            // station label rounding only
  property real fromToThreshold: 5.0 // metres past a waypoint before the display switches to the next one
  property int autoInc: 1            // +1 / -1
  property real machOffset: 0        // m, in-line, + = ahead of the antenna (NavMini "Vibe offset") - normally 0
  property real trackDist: 5         // log a track point every N metres (0 = off)
  property real trackSecs: 0         // and/or every N seconds (0 = off)
  property real qTol: 2              // HDOP limit: readout goes red above this (0 = off)
  property real streamInterval: 10.0 // MARK stream interval (m)
  property string machineId: ""      // e.g. DOZER1 - goes in the file names and the Machine column
  property bool csvLog: true
  property bool showTrail: true
  property bool alarmSound: true
  property bool autoPickLine: false
  property int nogoAlarmMs: 2500
  property int warnInitialMs: 4000
  property int warnInitialPhaseMs: 12000
  property int warnSustainedMs: 8000

  // ---- state ----
  property var lines: ({})
  property var nogoZones: []
  property var warnZones: []
  property var advPts: []
  property string curLine: ""
  property int dir: 1
  property bool follow: true
  property real lastCx: NaN
  property real lastCy: NaN
  property real lastRot: NaN
  property bool navView: true
  property bool streaming: false
  property var nav: null
  property var nogoHits: []
  property var warnHits: []
  property string zoneStat: "clear"
  property double zoneSince: 0
  property string advText: ""
  property string advKey: ""
  property real hdop: 0
  property real hacc: -1
  property real elev: NaN
  property real speedKmh: 0
  property real posX: 0
  property real posY: 0
  property real heading: 0
  property real lastHX: 0
  property real lastHY: 0
  property real lastStreamX: 0
  property real lastStreamY: 0
  property bool haveFix: false
  property int nSats: 0
  property string qualDesc: ""
  property double lastUpdate: 0
  property int nextMarkId: 1
  property string lastCode: ""
  property int lastString: 0
  property string statusText: ""
  property string recLabel: ""
  property bool recWarn: false
  property string clockText: ""
  property real autoPickDist: 50

  // QField's own full-screen pages (settings, project picker, cloud ...). While one is open the NM overlay hides.
  property var qfScreens: []
  property bool mapClear: true
  function findQfScreens() {
    var names = ["qfieldSettings", "welcomeScreen", "projectCreationScreen", "qfieldCloudScreen",
                 "qfieldLocalDataPickerScreen", "messageLog", "sketcher", "codeReader"], out = [];
    for (var i = 0; i < names.length; i++) {
      try { var it = iface.findItemByObjectName(names[i]); if (it) out.push(it); } catch (ef) {}
    }
    qfScreens = out;
  }
  function refreshMapClear() {
    var clear = true;
    for (var i = 0; i < qfScreens.length; i++) {
      try { if (qfScreens[i].visible) { clear = false; break; } } catch (ev) {}
    }
    if (mapClear !== clear) mapClear = clear;
  }
  Timer { interval: 250; repeat: true; running: plugin.qfScreens.length > 0; onTriggered: plugin.refreshMapClear() }
  Timer { interval: 1000; repeat: true; running: true; triggeredOnStart: true
    onTriggered: plugin.clockText = Qt.formatTime(new Date(), "hh:mm:ss") }

  function toast(msg) { mainWindow.displayToast(msg); }

  // ---- remembered settings (per QField project) ----
  property var store: null
  property string storeErr: ""
  function initStore() {
    try {
      var key = "NM";
      try { var bn = qgisProject.baseName; if (bn) key += "_" + bn; } catch (e0) {}
      var cat = key.replace(/[^A-Za-z0-9_]/g, "_");
      var tries = ['import QtQuick; import QtCore; Settings { category: "' + cat + '" }',
                   'import QtQuick 2.0; import Qt.labs.settings 1.0; Settings { category: "' + cat + '" }'];
      store = null; storeErr = "";
      for (var i = 0; i < tries.length && store === null; i++) {
        try { store = Qt.createQmlObject(tries[i], plugin, "nmstore" + i); } catch (e1) { storeErr += " [" + i + "] " + e1; store = null; }
      }
    } catch (e) { store = null; storeErr = String(e); }
  }
  readonly property var persistNums: ["xTol", "fromToThreshold", "autoInc", "machOffset", "trackDist", "trackSecs", "qTol", "streamInterval", "advDist", "markerSize", "bearLen"]
  readonly property var persistStrs: ["machineId", "preplotName", "stationField", "lineField", "trackLayerName", "marksLayerName", "advLayerName", "advField", "markerSym", "markerCol", "lineStyle", "lineCol"]
  readonly property var persistBools: ["alarmSound", "navView", "csvLog", "showTrail", "autoPickLine"]
  function saveSettings() {
    if (!store) return;
    try {
      var i;
      for (i = 0; i < persistNums.length; i++) store.setValue(persistNums[i], String(plugin[persistNums[i]]));
      for (i = 0; i < persistBools.length; i++) store.setValue(persistBools[i], plugin[persistBools[i]] ? "1" : "0");
      for (i = 0; i < persistStrs.length; i++) store.setValue(persistStrs[i], String(plugin[persistStrs[i]]));
      store.setValue("curLine", curLine); store.setValue("dir", String(dir));
      store.setValue("saved", "1");
      try { store.sync(); } catch (es) {}
    } catch (e) {}
  }
  function loadSettings() {
    if (!store) return;
    try {
      if (String(store.value("saved", "0")) !== "1") return;
      var i, v;
      for (i = 0; i < persistNums.length; i++) { v = parseFloat(store.value(persistNums[i], "")); if (!isNaN(v)) plugin[persistNums[i]] = v; }
      for (i = 0; i < persistStrs.length; i++) { v = store.value(persistStrs[i], undefined); if (v !== undefined && v !== null) plugin[persistStrs[i]] = String(v); }
      for (i = 0; i < persistBools.length; i++) { v = String(store.value(persistBools[i], "")); if (v === "1") plugin[persistBools[i]] = true; else if (v === "0") plugin[persistBools[i]] = false; }
    } catch (e) {}
  }
  function restoreLine() {
    if (!store) return;
    try {
      var id = String(store.value("curLine", ""));
      if (id !== "" && lines[id] && curLine === "") {
        var d = parseInt(store.value("dir", "1"));
        curLine = id; dir = d < 0 ? -1 : 1; nav = null;
        if (haveFix) nav = locate2D(lines[id], posX, posY, dir, fromToThreshold);
      }
    } catch (e) {}
  }
  // degrees-minutes-seconds of a bearing (radians), e.g. 356° 00' 28"
  function dms(r) {
    var d = deg(r), D = Math.floor(d), m = (d - D) * 60, M = Math.floor(m), S = Math.round((m - M) * 60);
    if (S >= 60) { S = 0; M++; }
    if (M >= 60) { M = 0; D++; }
    if (D >= 360) D -= 360;
    return D + "° " + ("0" + M).slice(-2) + "' " + ("0" + S).slice(-2) + '"';
  }
  function liveStnLabel() {
    if (!nav || curLine === "" || !lines[curLine]) return "--";
    try { return snapStation(lines[curLine], nav.chain, aTol).label; } catch (e) { return "--"; }
  }
  function fmt(v, d) { return (v === undefined || v === null || isNaN(v)) ? "--" : Number(v).toFixed(d); }

  // ==================================================================== CORE (generated)
  // nav25core.js - pure logic for the Nav25 QField plugin (no QField dependencies).
  // Rules come from the Nav12/Nav25 user guide (Terrex Spatial). Coordinates are projected metres.
  // This file is inlined into main.qml by build.py and unit-tested with node (test/test_core.js).

  // ---------- WKT parsing ----------
  function parseWktNumbers(s) {
      var out = [], parts = s.split(",");
      for (var i = 0; i < parts.length; i++) {
          var n = parts[i].trim().split(/\s+/);
          if (n.length >= 2) out.push([parseFloat(n[0]), parseFloat(n[1])]);
      }
      return out;
  }
  function parseWkt(wkt) {
      var t = wkt.trim().toUpperCase();
      var body = wkt.substring(wkt.indexOf("("));
      body = body.replace(/\bZM?\b/gi, "");
      var res = {type: "", polys: [], lines: [], points: []};
      var i;
      if (t.indexOf("MULTIPOLYGON") === 0) {
          res.type = "polygon";
          var polys = body.slice(3, -3).split(")),((");
          for (i = 0; i < polys.length; i++) res.polys.push(polys[i].split("),(").map(parseWktNumbers));
      } else if (t.indexOf("POLYGON") === 0) {
          res.type = "polygon";
          res.polys.push(body.slice(2, -2).split("),(").map(parseWktNumbers));
      } else if (t.indexOf("MULTIPOINT") === 0) {
          res.type = "point";
          res.points = parseWktNumbers(body.replace(/[()]/g, ""));
      } else if (t.indexOf("POINT") === 0) {
          res.type = "point";
          res.points = parseWktNumbers(body.slice(1, -1));
      } else if (t.indexOf("MULTILINESTRING") === 0) {
          res.type = "line";
          res.lines = body.slice(2, -2).split("),(").map(parseWktNumbers);
      } else if (t.indexOf("LINESTRING") === 0) {
          res.type = "line";
          res.lines.push(parseWktNumbers(body.slice(1, -1)));
      }
      return res;
  }

  // ---------- zones (No-Go = red, Warning = orange) ----------
  function ringContains(ring, x, y) {
      var inside = false;
      for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
          var xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
          if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside;
      }
      return inside;
  }
  function polyContains(rings, x, y) {
      if (!ringContains(rings[0], x, y)) return false;
      for (var k = 1; k < rings.length; k++) if (ringContains(rings[k], x, y)) return false;
      return true;
  }
  function bboxOf(rings) {
      var minx = 1e99, miny = 1e99, maxx = -1e99, maxy = -1e99, r = rings[0];
      for (var i = 0; i < r.length; i++) {
          if (r[i][0] < minx) minx = r[i][0];
          if (r[i][0] > maxx) maxx = r[i][0];
          if (r[i][1] < miny) miny = r[i][1];
          if (r[i][1] > maxy) maxy = r[i][1];
      }
      return [minx, miny, maxx, maxy];
  }
  function makeZone(name, parsed) {
      var z = {name: name, polys: parsed.polys, bbox: []};
      for (var i = 0; i < parsed.polys.length; i++) z.bbox.push(bboxOf(parsed.polys[i]));
      return z;
  }
  // returns the names of every zone containing (x,y)
  function zoneHits(zones, x, y) {
      var hits = [];
      for (var z = 0; z < zones.length; z++) {
          var Z = zones[z];
          for (var p = 0; p < Z.polys.length; p++) {
              var b = Z.bbox[p];
              if (x < b[0] || x > b[2] || y < b[1] || y > b[3]) continue;
              if (polyContains(Z.polys[p], x, y)) { hits.push(Z.name); break; }
          }
      }
      return hits;
  }
  // alarm state: "nogo" (red) beats "warn" (orange) beats "clear" (green)
  function zoneState(nogoHits, warnHits) {
      if (nogoHits.length > 0) return "nogo";
      if (warnHits.length > 0) return "warn";
      return "clear";
  }

  // ---------- preplot lines (2D Stakeout waypoints) ----------
  function buildLines(rows) {
      var lines = {}, i;
      for (i = 0; i < rows.length; i++) {
          var r = rows[i];
          if (!lines[r.line]) lines[r.line] = {id: r.line, pts: [], length: 0};
          lines[r.line].pts.push({stn: r.stn, x: r.x, y: r.y, chain: 0});
      }
      for (var id in lines) {
          var L = lines[id];
          L.pts.sort(function (a, b) { return a.stn - b.stn; });
          var c = 0;
          for (i = 0; i < L.pts.length; i++) {
              if (i > 0) c += Math.hypot(L.pts[i].x - L.pts[i - 1].x, L.pts[i].y - L.pts[i - 1].y);
              L.pts[i].chain = c;
          }
          L.length = c;
      }
      return lines;
  }
  // typical station interval of a line (median of consecutive spacing per station step)
  function lineInterval(L) {
      var d = [];
      for (var i = 1; i < L.pts.length; i++) {
          var ds = Math.abs(L.pts[i].stn - L.pts[i - 1].stn);
          if (ds > 0) d.push(Math.hypot(L.pts[i].x - L.pts[i - 1].x, L.pts[i].y - L.pts[i - 1].y) / ds);
      }
      if (d.length === 0) return 0;
      d.sort(function (a, b) { return a - b; });
      return d[Math.floor(d.length / 2)];
  }

  function bearing(x0, y0, x1, y1) { return Math.atan2(x1 - x0, y1 - y0); }
  function wrapPi(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function deg(r) { return (r * 180 / Math.PI + 360) % 360; }

  // 2D Stakeout guidance. Bearings are those of the segment between consecutive waypoints.
  // dir = +1 / -1 (AutoInc).  thr = From/To threshold: how far PAST a waypoint the display keeps
  // showing the distance back to it before it switches to the next waypoint.
  // atrack: + = target still ahead, - = target already passed (within thr).
  // xtrack: + = right of the direction of travel.
  function locate2D(L, px, py, dir, thr) {
      var pts = L.pts, best = null, i;
      if (pts.length < 2) return null;
      for (i = 0; i < pts.length - 1; i++) {
          var a = pts[i], b = pts[i + 1];
          var dx = b.x - a.x, dy = b.y - a.y, len2 = dx * dx + dy * dy;
          if (len2 === 0) continue;
          var t = ((px - a.x) * dx + (py - a.y) * dy) / len2;
          var tc = Math.max(0, Math.min(1, t));
          var fx = a.x + tc * dx, fy = a.y + tc * dy;
          var d = Math.hypot(px - fx, py - fy);
          if (best === null || d < best.dist) {
              var seglen = Math.sqrt(len2);
              var tAlong = (i === 0 && t < 0) ? t : (i === pts.length - 2 && t > 1 ? t : tc);
              best = {seg: i, dist: d, fx: fx, fy: fy, chain: a.chain + tAlong * seglen,
                      rawX: ((px - a.x) * dy - (py - a.y) * dx) / seglen, brg: Math.atan2(dx, dy), t: tAlong};
          }
      }
      if (best === null) return null;
      var sgn = dir >= 0 ? 1 : -1;
      var segA = pts[best.seg], segB = pts[best.seg + 1];
      var stn = segA.stn + best.t * (segB.stn - segA.stn);
      // waypoints in travel order, starting at the segment's near end
      var order = [];
      if (sgn > 0) { for (i = best.seg; i < pts.length; i++) order.push(i); }
      else { for (i = best.seg + 1; i >= 0; i--) order.push(i); }
      var target = order[order.length - 1], k, along;
      for (k = 0; k < order.length; k++) {
          along = (pts[order[k]].chain - best.chain) * sgn;
          if (along >= -thr) { target = order[k]; break; }
      }
      var tp = pts[target];
      var endPt = sgn > 0 ? pts[pts.length - 1] : pts[0];
      var tIdx = order.indexOf(target);
      var nextIdx = tIdx >= 0 && tIdx + 1 < order.length ? order[tIdx + 1] : -1;
      return {
          xtrack: best.rawX * sgn, chain: best.chain, stn: stn,
          foot: [best.fx, best.fy], travelBearing: best.brg + (sgn > 0 ? 0 : Math.PI),
          seg: best.seg, off: best.dist,
          fromStn: sgn > 0 ? segA.stn : segB.stn, toStn: sgn > 0 ? segB.stn : segA.stn,
          targetStn: tp.stn, targetX: tp.x, targetY: tp.y,
          atrack: (tp.chain - best.chain) * sgn,
          nextStn: nextIdx >= 0 ? pts[nextIdx].stn : null,
          toEnd: (endPt.chain - best.chain) * sgn
      };
  }
  // Target Lock: the target-locked display first appears when both ATrack and XTrack are within gates
  function targetLocked(nav, aTol, xTol) {
      return Math.abs(nav.atrack) <= aTol && Math.abs(nav.xtrack) <= xTol;
  }
  function nearestLines(lines, px, py, maxN) {
      var out = [];
      for (var id in lines) {
          var l = locate2D(lines[id], px, py, 1, 0);
          if (l) out.push({id: id, off: l.off});
      }
      out.sort(function (a, b) { return a.off - b.off; });
      return maxN ? out.slice(0, maxN) : out;
  }

  // ---------- Go Home / waypoint (WP) mode ----------
  function wpGuidance(px, py, tx, ty, travelBrg) {
      var brg = bearing(px, py, tx, ty);
      return {dist: Math.hypot(tx - px, ty - py), brg: brg, rel: wrapPi(brg - travelBrg)};
  }
  function findStation(lines, lineId, stn) {
      var L = lines[lineId];
      if (!L) return null;
      for (var i = 0; i < L.pts.length; i++) if (L.pts[i].stn === stn) return L.pts[i];
      return null;
  }

  // ---------- recording QA (Nav "warning message when recording a point") ----------
  // prev1/prev2: the last two recorded Line Stations on this line {x,y,stn} (prev2 may be null)
  // cand: {x,y,stn}; p: {stnInterval, maxIntvl, maxBend, distTol}
  // q: {hacc, vacc, hdop, pTol, zTol, qTol}
  function recordWarnings(prev1, prev2, cand, p, q) {
      var w = [];
      if (prev1) {
          var d = Math.hypot(cand.x - prev1.x, cand.y - prev1.y);
          var dStn = Math.abs(cand.stn - prev1.stn);
          if (p.maxIntvl > 0 && d > p.maxIntvl) w.push("Interval " + d.toFixed(1) + " m > MaxIntvl " + p.maxIntvl);
          if (p.stnInterval > 0 && dStn > 0 && p.distTol > 0) {
              var exp = p.stnInterval * dStn;
              var pct = Math.abs(d - exp) / exp * 100;
              if (pct > p.distTol) w.push("Distance error " + pct.toFixed(0) + "% (" + d.toFixed(1) + " m vs " + exp.toFixed(1) + " m)");
          }
          if (prev2 && p.maxBend > 0) {
              var b1 = bearing(prev2.x, prev2.y, prev1.x, prev1.y), b2 = bearing(prev1.x, prev1.y, cand.x, cand.y);
              var bend = Math.abs(wrapPi(b2 - b1)) * 180 / Math.PI;
              if (bend > p.maxBend) w.push("Bend " + bend.toFixed(0) + "° > MaxBend " + p.maxBend + "°");
          }
      }
      if (q) {
          if (q.pTol > 0 && q.hacc > 0 && q.hacc > q.pTol) w.push("Horiz precision " + q.hacc.toFixed(2) + " m > PTol " + q.pTol);
          if (q.zTol > 0 && q.vacc > 0 && q.vacc > q.zTol) w.push("Vert precision " + q.vacc.toFixed(2) + " m > ZTol " + q.zTol);
          if (q.qTol > 0 && q.hdop > 0 && q.hdop > q.qTol) w.push("HDOP " + q.hdop.toFixed(1) + " > QTol " + q.qTol);
      }
      return w;
  }

  // ---------- recorded-point helpers ----------
  // Nav combines Feature Code and String No into one label; consecutive identical labels with
  // a non-zero string number are joined by lines.
  function featureLabel(code, stringNo) {
      var s = parseInt(stringNo || 0);
      return String(code || "") + (s > 0 ? (s < 10 ? "0" + s : String(s)) : "");
  }
  function lineKey(descriptor) { return String(descriptor).replace(/^[A-Za-z]+/, ""); }
  function stationOf(raw, line, hasPrefix) {
      var v = Math.round(parseFloat(raw));
      if (!hasPrefix) return v;
      var s = String(v);
      return s.indexOf(line) === 0 && s.length > line.length ? parseInt(s.substring(line.length)) : v;
  }
  // running average of N observations (Nav "Average (50 obs)")
  function newAverager() { return {n: 0, x: 0, y: 0, z: 0, nz: 0}; }
  function addObs(a, x, y, z) {
      a.n++; a.x += x; a.y += y;
      if (z !== null && z !== undefined && !isNaN(z)) { a.z += z; a.nz++; }
  }
  function averageOf(a) { return {x: a.x / a.n, y: a.y / a.n, z: a.nz > 0 ? a.z / a.nz : NaN, n: a.n}; }

  // ---------- alarm timing (Nav25: Warning alarm has a fast initial phase, then a slower sustained one) ----------
  function alarmIntervalMs(state, msInState, c) {
      if (state === "nogo") return c.nogoMs;
      if (state === "warn") return msInState < c.warnInitialPhaseMs ? c.warnInitialMs : c.warnSustainedMs;
      return 0;
  }

  // ---------- station + offset (what a recorded Line Station always carries) ----------
  // chain = distance along the line at the recorded position (locate2D().chain).
  // The point is always tied to the NEAREST preplot station. offset = signed metres from that
  // station, + toward higher station numbers.  Offsets within aTol are rounded onto the station.
  function snapStation(L, chain, aTol) {
      var best = 0, bd = 1e99, i;
      for (i = 0; i < L.pts.length; i++) {
          var d = Math.abs(L.pts[i].chain - chain);
          if (d < bd) { bd = d; best = i; }
      }
      var off = chain - L.pts[best].chain;
      var snapped = Math.abs(off) <= aTol;
      if (snapped) off = 0;
      off = Math.round(off * 10) / 10;
      return {stn: L.pts[best].stn, offset: off, snapped: snapped, label: stationLabel(L.pts[best].stn, off)};
  }
  function stationLabel(stn, off) {
      if (!off) return String(stn);
      return String(stn) + (off > 0 ? "+" : "-") + Math.abs(off).toFixed(1);
  }
  // Crossline gate: a Line Station is only recorded when |XTrack| <= xTol
  function recordAllowed(nv, xTol) {
      if (!nv) return {ok: false, msg: "No line / position on line"};
      if (xTol > 0 && Math.abs(nv.xtrack) > xTol)
          return {ok: false, msg: "XTrack " + Math.abs(nv.xtrack).toFixed(1) + " m " + (nv.xtrack > 0 ? "R" : "L") + " is outside XTol " + xTol + " m"};
      return {ok: true, msg: ""};
  }

  // ---------- Stakeless: stations passed between two consecutive fixes ----------
  // cPrev/cNow: chain along the line at the previous / current fix; pPrev/pNow: {x,y} of the fixes.
  // Returns [{stn, x, y}] - each station whose chainage was crossed (in the direction of travel),
  // with the position interpolated along the travelled route between the two fixes.
  // Jumps longer than maxJump (m) are ignored (line change, GPS glitch).
  function stakelessCrossings(L, dir, cPrev, cNow, pPrev, pNow, maxJump) {
      var out = [], sgn = dir >= 0 ? 1 : -1;
      var a = sgn * cPrev, b = sgn * cNow;
      if (!(b > a) || (b - a) > maxJump) return out;
      for (var i = 0; i < L.pts.length; i++) {
          var cs = sgn * L.pts[i].chain;
          if (cs > a && cs <= b) {
              var t = (cs - a) / (b - a);
              out.push({stn: L.pts[i].stn, x: pPrev.x + t * (pNow.x - pPrev.x), y: pPrev.y + t * (pNow.y - pPrev.y)});
          }
      }
      if (sgn < 0) out.reverse();
      return out;
  }
  // ==================================================================== end CORE

  // ------------------------------------------------------------------ loading (preplot lines, NG_ / WZ_ zones, advisories)
  property bool loading: false
  property bool loadedOnce: false
  property bool pendingPicker: false
  property var loadJobs: []
  property var loadJob: null
  property var loadIt: null
  property var loadRows: []
  property var loadNogo: []
  property var loadWarn: []
  property var loadAdv: []
  property int loadCount: 0

  function layerByName(name) {
    var l = qgisProject.mapLayersByName(name);
    return l.length > 0 ? l[0] : null;
  }
  function geomIn(layer, feature) {
    var g = feature.geometry;
    if (layer.crs.authid !== qgisProject.crs.authid)
      g = QfGeometryUtils.reprojectGeometry(g, layer.crs, qgisProject.crs);
    return g;
  }
  function failLoad(e) {
    loadTimer.stop(); loading = false; loadIt = null;
    statusText = "LOAD ERROR: " + e;
    toast("NM: " + e);
  }
  function addJob(jobs, seen, kind, layer) {
    if (!layer) return;
    var key = kind + "|" + layer.id;
    if (seen[key]) return;
    seen[key] = true;
    jobs.push({kind: kind, layer: layer});
  }

  // ---- auto-detect the preplot layer and its station / line fields (so the same plugin runs in any project) ----
  readonly property var stnCands: ["Stn", "Station", "Stn_No", "StnNo", "Station_No", "StationNo", "Sta", "STN", "Point", "PointID", "Point_ID", "SP", "ATTR_1"]
  readonly property var lineCands: ["Line_ID", "LineID", "Line", "Line_No", "LineNo", "Line_Name", "LineName", "LINE", "ATTR_2"]
  function firstField(layer, cands) {
    for (var i = 0; i < cands.length; i++) {
      var ix = -1;
      try { ix = layer.fields.indexFromName(cands[i]); } catch (e) { return ""; }
      if (ix >= 0) { try { return String(layer.fields.at(ix).name); } catch (e2) { return cands[i]; } }
    }
    // fuzzy pass: field names that start with a candidate, e.g. "Line Numbe" / "Point Numb" from truncated shapefile names
    try {
      var norm = function (t) { return String(t).toLowerCase().replace(/[^a-z0-9]/g, ""); };
      var nf = layer.fields.count();
      for (var c = 0; c < cands.length; c++) {
        var cn = norm(cands[c]);
        if (cn.length < 4) continue;
        for (var k = 0; k < nf; k++) {
          var fname = String(layer.fields.at(k).name), fn = norm(fname);
          if (fn.indexOf(cn) === 0 && fn.indexOf("part") < 0 && fn.indexOf("type") < 0) return fname;
        }
      }
    } catch (e3) {}
    return "";
  }
  function isOwnLayer(nm) {
    return /^NM_/i.test(nm) || /^(N25|NS)_/i.test(nm) || nm.indexOf(noGoPrefix) === 0 || nm.indexOf(warnPrefix) === 0
        || nm.toUpperCase().indexOf("WARN") === 0 || (advLayerName !== "" && nm === advLayerName);
  }
  function autoPreplot() {
    var best = "", bestScore = -1, bs = "", bl = "";
    try {
      var all = QfProjectUtils.mapLayers(qgisProject);
      for (var key in all) {
        var l = all[key];
        if (!l || l.name === undefined) continue;
        var nm = String(l.name);
        if (isOwnLayer(nm)) continue;
        var sf = "", lf = "";
        try {
          sf = stationField !== "" ? (l.fields.indexFromName(stationField) >= 0 ? stationField : "") : firstField(l, stnCands);
          lf = lineField !== "" ? (l.fields.indexFromName(lineField) >= 0 ? lineField : "") : firstField(l, lineCands);
        } catch (e) { continue; }
        if (sf === "" || lf === "") continue;
        var score = 1;
        if (/preplot|plot|rcv|receiver|node|station|src|source|point/i.test(nm)) score += 2;
        if (/preplot/i.test(nm)) score += 1;
        if (/src|source|shot/i.test(nm)) score += 0.5;
        if (score > bestScore) { bestScore = score; best = nm; bs = sf; bl = lf; }
      }
    } catch (e3) {}
    if (best === "") return [];
    if (stnUse === "") stnUse = bs;
    if (lineUse === "") lineUse = bl;
    return [best];
  }

  function startLoad() {
    if (loading) return;
    try {
      var jobs = [], seen = {}, i, layer, missing = [];
      stnUse = stationField; lineUse = lineField; preplotInfo = "";
      var pnames = preplotName !== "" ? [preplotName] : preplotLayerNames.slice();
      if (pnames.length === 0) pnames = autoPreplot();
      for (i = 0; i < pnames.length; i++) {
        layer = layerByName(pnames[i]);
        if (layer) addJob(jobs, seen, "preplot", layer); else missing.push(pnames[i]);
      }
      if (pnames.length > 0) {
        var pl0 = layerByName(pnames[0]);
        if (pl0 && stnUse === "") stnUse = firstField(pl0, stnCands);
        if (pl0 && lineUse === "") lineUse = firstField(pl0, lineCands);
      }
      if (pnames.length > 0 && missing.length === 0) preplotInfo = pnames.join(", ") + " (" + stnUse + " / " + lineUse + ")";
      var all = QfProjectUtils.mapLayers(qgisProject);
      for (var key in all) {
        layer = all[key];
        if (!layer || layer.name === undefined) continue;
        if (layer.name.indexOf(noGoPrefix) === 0) addJob(jobs, seen, "nogo", layer);
        else if (layer.name.indexOf(warnPrefix) === 0 || layer.name.toUpperCase().indexOf("WARN") === 0) addJob(jobs, seen, "warn", layer);
      }
      if (advLayerName !== "") {
        var al = layerByName(advLayerName);
        if (al) addJob(jobs, seen, "adv", al); else toast("NM: advisory layer '" + advLayerName + "' not found");
      }
      if (missing.length > 0) toast("NM: preplot layer(s) not found: " + missing.join(", "));
      if (pnames.length === 0) toast("NM: no preplot layer found - set its name in the NM settings");
      if (jobs.length === 0) { statusText = "No preplot / zone layers found in this project"; return; }
      loadJobs = jobs; loadJob = null; loadIt = null;
      loadRows = []; loadNogo = []; loadWarn = []; loadAdv = []; loadCount = 0;
      loading = true; statusText = "Loading layers...";
      loadTimer.start();
    } catch (e) { failLoad(e); }
  }

  function advTextField(layer) {
    // advisory text: the chosen field, else the first text field after the first column (NavMini uses column 1 as the label)
    try {
      if (advField !== "" && layer.fields.indexFromName(advField) >= 0) return advField;
      var n = layer.fields.count();
      for (var k = 1; k < n; k++) {
        var tn = String(layer.fields.at(k).typeName).toLowerCase();
        if (tn.indexOf("string") >= 0 || tn.indexOf("text") >= 0 || tn.indexOf("char") >= 0) return String(layer.fields.at(k).name);
      }
      if (n > 1) return String(layer.fields.at(1).name);
    } catch (e) {}
    return "";
  }
  property string loadAdvText: ""
  property string loadAdvLabel: ""

  function processFeature(f) {
    var job = loadJob;
    if (job.kind === "adv") {
      var pa = parseWkt(geomIn(job.layer, f).asWkt(2));
      if (pa.points.length === 0) return;
      loadAdv.push({x: pa.points[0][0], y: pa.points[0][1], label: String(f.attribute(loadAdvLabel) || ""), text: loadAdvText !== "" ? String(f.attribute(loadAdvText) || "") : ""});
      loadCount++;
      return;
    }
    var p = parseWkt(geomIn(job.layer, f).asWkt(job.kind === "preplot" ? 3 : 2));
    if (job.kind === "preplot") {
      if (p.points.length === 0) return;
      var ln = lineKey(f.attribute(lineUse));
      loadRows.push({line: ln, stn: stationOf(f.attribute(stnUse), ln, stationHasLinePrefix), x: p.points[0][0], y: p.points[0][1]});
    } else if (p.type === "polygon") {
      (job.kind === "nogo" ? loadNogo : loadWarn).push(makeZone(job.layer.name, p));
    }
    loadCount++;
  }

  function loadStep() {
    try {
      var t0 = Date.now();
      while (Date.now() - t0 < 40) {
        if (loadIt === null) {
          if (loadJobs.length === 0) { finishLoad(); return; }
          loadJob = loadJobs.shift();
          if (loadJob.kind === "adv") {
            try { loadAdvLabel = String(loadJob.layer.fields.at(0).name); } catch (ea) { loadAdvLabel = ""; }
            loadAdvText = advTextField(loadJob.layer);
          }
          loadIt = QfLayerUtils.createFeatureIterator(loadJob.layer);
          statusText = "Loading " + loadJob.layer.name + "...  (" + loadCount + ")";
          continue;
        }
        if (!loadIt.hasNext()) { loadIt.close(); loadIt = null; continue; }
        processFeature(loadIt.next());
      }
    } catch (e) { failLoad(e); }
  }

  function finishLoad() {
    loadTimer.stop(); loading = false;
    lines = buildLines(loadRows);
    nogoZones = loadNogo; warnZones = loadWarn; advPts = loadAdv;
    loadedOnce = true;
    var n = 0; for (var q in lines) n++;
    statusText = n + " lines, " + nogoZones.length + " No-Go, " + warnZones.length + " Warning zones"
               + (advPts.length > 0 ? ", " + advPts.length + " advisories" : "")
               + (preplotInfo !== "" ? "  |  preplot: " + preplotInfo : "");
    restoreLine();
    toast("NM ready: " + statusText + (curLine !== "" ? "  (line " + curLine + ")" : ""));
    if (pendingPicker) { pendingPicker = false; linePopup.openPicker(); }
  }
  Timer { id: loadTimer; interval: 5; repeat: true; running: false; onTriggered: plugin.loadStep() }

  // ------------------------------------------------------------------ sounds (the NavMini geofence clips)
  property var sndNogo: null
  property var sndWarn: null
  property var sndInfo: null
  property bool soundOk: false
  function initSounds() {
    try {
      sndNogo = Qt.createQmlObject('import QtMultimedia\nSoundEffect { volume: 1.0 }', plugin, "nmNogoSnd");
      sndWarn = Qt.createQmlObject('import QtMultimedia\nSoundEffect { volume: 1.0 }', plugin, "nmWarnSnd");
      sndInfo = Qt.createQmlObject('import QtMultimedia\nSoundEffect { volume: 1.0 }', plugin, "nmInfoSnd");
      sndNogo.source = Qt.resolvedUrl("geofence_breach.wav");
      sndWarn.source = Qt.resolvedUrl("geofence_warning.wav");
      sndInfo.source = Qt.resolvedUrl("geofence_info.wav");
      soundOk = true;
    } catch (e) {
      soundOk = false;
      statusText = "Sound unavailable (" + e + ") - visual alarm only";
    }
  }
  function playAlarm() {
    if (!alarmSound || !soundOk) return;
    try {
      if (zoneStat === "nogo") sndNogo.play();
      else if (zoneStat === "warn") sndWarn.play();
    } catch (e) {}
  }
  function playInfo() {
    if (!alarmSound || !soundOk) return;
    try { if (zoneStat === "clear") sndInfo.play(); } catch (e) {}
  }
  function alarmCfg() {
    return {nogoMs: nogoAlarmMs, warnInitialMs: warnInitialMs, warnInitialPhaseMs: warnInitialPhaseMs, warnSustainedMs: warnSustainedMs};
  }
  function setZoneState(s) {
    if (s === zoneStat) return;
    zoneStat = s;
    zoneSince = Date.now();
    if (s === "clear") { alarmTimer.stop(); return; }
    toast(s === "nogo" ? "NO-GO ZONE: " + nogoHits.join(", ") : "WARNING ZONE: " + warnHits.join(", "));
    playAlarm();
    alarmTimer.interval = alarmIntervalMs(s, 0, alarmCfg());
    alarmTimer.restart();
  }
  Timer {
    id: alarmTimer
    repeat: true; running: false
    onTriggered: {
      plugin.playAlarm();
      var iv = plugin.alarmIntervalMs(plugin.zoneStat, Date.now() - plugin.zoneSince, plugin.alarmCfg());
      if (iv > 0) interval = iv;
    }
  }

  // advisory: nearest advisory point within advDist shows its text; the info clip plays once on entering it
  function advisoryCheck(x, y) {
    if (advPts.length === 0 || advDist <= 0) { advText = ""; advKey = ""; return; }
    var best = null, bd = 1e99;
    for (var i = 0; i < advPts.length; i++) {
      var p = advPts[i];
      if (Math.abs(p.x - x) > advDist || Math.abs(p.y - y) > advDist) continue;
      var d = Math.hypot(p.x - x, p.y - y);
      if (d <= advDist && d < bd) { bd = d; best = p; }
    }
    if (best) {
      advText = (best.label !== "" ? best.label + ": " : "") + best.text + "  (" + bd.toFixed(0) + " m)";
      var k = best.label + "|" + best.x + "|" + best.y;
      if (k !== advKey) { advKey = k; playInfo(); }
    } else { advText = ""; advKey = ""; }
  }

  // ------------------------------------------------------------------ position / navigation
  function firstPositive(info, names) {
    for (var i = 0; i < names.length; i++) {
      var v;
      try { v = info[names[i]]; } catch (e) { continue; }
      if (v !== undefined && v !== null && !isNaN(v) && Number(v) > 0) return Number(v);
    }
    return -1;
  }
  function qBad() { return qTol > 0 && !(hdop > 0 && hdop <= qTol); }
  // GPS quality 1 (best) .. 5 (worst): receiver fix type first, then bumped one step if HDOP is over the limit
  function qualityNum() {
    if (!positioning.active || !haveFix) return 5;
    var qd = qualDesc, n;
    var known = (qd !== "" && !/unknown/i.test(qd));
    if (known) {
      if (/float/i.test(qd)) n = 2;
      else if (/rtk|fixed/i.test(qd)) n = 1;
      else if (/dgps|differential/i.test(qd)) n = 3;
      else n = 4;
      if (hdop > 0 && qTol > 0 && hdop > qTol) n += 1;
    } else {
      // no fix type reported (phone GPS): go by accuracy, then HDOP
      if (hacc > 0) n = hacc <= 0.1 ? 1 : (hacc <= 0.5 ? 2 : (hacc <= 2 ? 3 : (hacc <= 5 ? 4 : 5)));
      else if (hdop > 0) n = (qTol > 0 && hdop > qTol) ? 4 : 3;
      else n = 4;
    }
    return Math.min(5, n);
  }

  function onPosition() {
    if (!positioning.active) return;
    var now = Date.now();
    if (now - lastUpdate < 450) return;
    lastUpdate = now;
    var info = positioning.positionInformation;
    var llOk = false;
    try { llOk = isFinite(info.latitude) && isFinite(info.longitude) && !(info.latitude === 0 && info.longitude === 0); } catch (ell) {}
    if (!info.latitudeValid && !llOk) { haveFix = false; return; }
    haveFix = true;
    var pp = positioning.projectedPosition;
    var x = pp.x, y = pp.y;
    hdop = info.hdop;
    hacc = firstPositive(info, ["hacc", "horizontalAccuracy", "horizontalAcc"]);
    elev = (info.elevation !== undefined && !isNaN(info.elevation) && info.elevationValid !== false) ? info.elevation : NaN;
    try { var ppz = pp.z; if (isFinite(ppz)) elev = ppz; } catch (ez) {}
    try { nSats = (info.satellitesUsed !== undefined && info.satellitesUsed > 0) ? info.satellitesUsed : 0; } catch (e2) { nSats = 0; }
    try { qualDesc = info.qualityDescription ? String(info.qualityDescription) : ""; } catch (e4) { qualDesc = ""; }
    try { speedKmh = (info.speedValid && info.speed >= 0) ? info.speed * 3.6 : 0; } catch (e5) { speedKmh = 0; }

    var moved = Math.hypot(x - lastHX, y - lastHY);
    if (info.directionValid && info.speedValid && info.speed > 0.5) heading = info.direction * Math.PI / 180;
    else if (moved > 1.0) heading = bearing(lastHX, lastHY, x, y);
    if (moved > 1.0) { lastHX = x; lastHY = y; }
    // machine offset: shift the antenna position along the direction of travel to the machine reference point
    if (machOffset !== 0) { x += machOffset * Math.sin(heading); y += machOffset * Math.cos(heading); }
    posX = x; posY = y;

    if (autoPickLine && curLine === "" && loadedOnce && !loading) {
      try {
        var nl = nearestLines(lines, x, y, 1);
        if (nl.length > 0 && nl[0].off <= autoPickDist) setLine(nl[0].id);
      } catch (eap) {}
    }
    if (curLine !== "" && lines[curLine]) nav = locate2D(lines[curLine], x, y, dir, fromToThreshold);

    nogoHits = zoneHits(nogoZones, x, y);
    warnHits = zoneHits(warnZones, x, y);
    setZoneState(zoneState(nogoHits, warnHits));
    advisoryCheck(x, y);

    trackTick(x, y);
    if (streaming && Math.hypot(x - lastStreamX, y - lastStreamY) >= streamInterval) streamPoint();

    if (follow) {
      // if the user has dragged the map away from where we last put it, stop following until FOLLOW is tapped
      try {
        var ms = mapCanvas.mapSettings, mupp = 0;
        try { mupp = ms.mapUnitsPerPoint; } catch (em1) { mupp = 0; }
        if (!(mupp > 0)) { try { mupp = ms.mapUnitsPerPixel; } catch (em2) { mupp = 0; } }
        if (!(mupp > 0)) mupp = 0.5;
        var cc = ms.center;
        if (isFinite(lastCx) && Math.hypot(cc.x - lastCx, cc.y - lastCy) > mupp * 12) {
          follow = false; toast("Map free - tap FOLLOW in the NM panel to recentre");
        }
        // something else turned the map (QField's blue locate button, a two-finger rotate): hand the map over
        if (follow && isFinite(lastRot)) {
          var dRot = Math.abs((((ms.rotation - lastRot) % 360) + 540) % 360 - 180);
          if (dRot > 3) {
            follow = false; lastRot = NaN;
            toast("NM follow off - QField is steering the map. Tap FOLLOW in the NM panel to take it back");
          }
        }
      } catch (ep) {}
    }
    if (follow) {
      mapCanvas.mapSettings.center = QfGeometryUtils.point(x, y);
      lastCx = x; lastCy = y;
      var tb = nav ? nav.travelBearing : null;
      if (navView && tb !== null) mapCanvas.mapSettings.rotation = -deg(tb);
      else if (!navView) mapCanvas.mapSettings.rotation = 0;
      if (navView && tb === null) lastRot = NaN;
      else { try { lastRot = mapCanvas.mapSettings.rotation; } catch (er) { lastRot = NaN; } }
    }
  }

  function setLine(id) {
    curLine = id; dir = autoInc; nav = null;
    if (haveFix && lines[id]) nav = locate2D(lines[id], posX, posY, dir, fromToThreshold);
    toast("Line " + id + (dir > 0 ? "  ▲ increasing" : "  ▼ decreasing"));
    saveSettings();
  }
  function toggleDir() {
    dir = -dir;
    if (haveFix && curLine !== "" && lines[curLine]) nav = locate2D(lines[curLine], posX, posY, dir, fromToThreshold);
    saveSettings();
  }
  function startStop() {
    try {
      if (!positioning.active) {
        positioning.active = true; toast("GPS started");
        if (!loadedOnce && !loading) startLoad();
      } else {
        positioning.active = false; streaming = false; haveFix = false;
        flushTrack();
        setZoneState("clear"); advText = ""; advKey = "";
        toast("GPS stopped");
      }
    } catch (e) { toast("GPS: " + e); }
  }

  // ------------------------------------------------------------------ logging: track + marks
  // CSV files go beside the project (NM_Track_<date>_<machine>.csv / NM_Marks_...). If the project also has layers called
  // NM_TrackPts / NM_Marks (names in settings) the points are added there too. Neither is required.
  property string csvStatus: ""
  function csvCell(v) {
    var t = (v === null || v === undefined) ? "" : String(v);
    return /[",\n\r]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
  }
  function p2(n) { return n < 10 ? "0" + n : String(n); }
  function dateIso(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function timeIso(d) { return p2(d.getHours()) + ":" + p2(d.getMinutes()) + ":" + p2(d.getSeconds()); }
  function rnd(v, n) { return (v === null || v === undefined || isNaN(v)) ? "" : Math.round(v * Math.pow(10, n)) / Math.pow(10, n); }
  function logPath(kind) {
    var d = new Date();
    var m = machineId.replace(/[^A-Za-z0-9_\-]/g, "");
    return String(qgisProject.homePath) + "/NM_" + kind + "_" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + (m !== "" ? "_" + m : "") + ".csv";
  }
  readonly property string trackHeader: "Date,Time,Machine,Line,Stn,XTrack,Easting,Northing,Elev,HDOP,Speed_kmh,Heading"
  readonly property string marksHeader: "MarkID,Date,Time,Machine,Code,StringNo,Label,Line,Stn,XTrack,Easting,Northing,Elev,HDOP,Remarks"
  function appendRows(path, header, rows) {
    try {
      var old = "";
      try { old = FileUtils.readFileContent(path); } catch (er) { old = ""; }
      if (old === undefined || old === null) old = "";
      old = String(old);
      var out = (old === "" ? header + "\r\n" : (old.slice(-1) === "\n" ? old : old + "\r\n"));
      var ok = FileUtils.writeFileContent(path, out + rows.join("\r\n") + "\r\n");
      csvStatus = (ok === false) ? "CSV write failed" : ("CSV: " + path.replace(/^.*\//, ""));
      return ok !== false;
    } catch (e) { csvStatus = "CSV not available: " + e; return false; }
  }

  // layer helpers (only used when the optional NM_TrackPts / NM_Marks layers exist)
  function setAttr(layer, feature, name, value) {
    if (value === null || value === undefined || value === "" || (typeof value === "number" && isNaN(value))) return;
    var idx = layer.fields.indexFromName(name);
    if (idx >= 0) feature.setAttribute(idx, value);
  }
  function pointIn(layer, x, y) {
    var g = QfGeometryUtils.createGeometryFromWkt("Point (" + x + " " + y + ")");
    if (layer.crs.authid !== qgisProject.crs.authid) g = QfGeometryUtils.reprojectGeometry(g, qgisProject.crs, layer.crs);
    return g;
  }
  // QField's LayerUtils.addFeature does not start/commit editing itself: start editing if needed, add, commit. Returns "" or an error text.
  function addFeatureTo(layer, f) {
    var wasEditable = false;
    try { wasEditable = layer.isEditable(); } catch (e0) { wasEditable = false; }
    if (!wasEditable) {
      var started = false;
      try { started = layer.startEditing(); } catch (e1) { return "startEditing error: " + e1; }
      if (!started) return "could not start editing (layer read-only?)";
    }
    var ok = false;
    try { ok = QfLayerUtils.addFeature(layer, f); } catch (e2) {
      if (!wasEditable) { try { layer.rollBack(); } catch (e3) {} }
      return "addFeature error: " + e2;
    }
    if (ok === false) {
      if (!wasEditable) { try { layer.rollBack(); } catch (e4) {} }
      return "addFeature refused the point";
    }
    if (!wasEditable) {
      var committed = false;
      try { committed = layer.commitChanges(); } catch (e5) { return "commit error: " + e5; }
      if (!committed) { try { layer.rollBack(); } catch (e6) {} return "commit failed (data provider rejected the point)"; }
    }
    return "";
  }
  function writePointLayer(layer, x, y, attrs) {
    try {
      var f = QfFeatureUtils.createFeature(layer, pointIn(layer, x, y));
      for (var k in attrs) setAttr(layer, f, k, attrs[k]);
      var err = addFeatureTo(layer, f);
      if (err !== "") { statusText = "ERROR: " + layer.name + " write failed - " + err; return false; }
      return true;
    } catch (e) { statusText = "ERROR: " + layer.name + " - " + e; return false; }
  }

  // ---- track ----
  property var trail: []            // decimated route (3 m) for the red trail drawn on the map
  property real trailX: 0
  property real trailY: 0
  property bool trailDirty: false
  property var trackBuf: []
  property real trkX: 0
  property real trkY: 0
  property double trkT: 0
  property bool trkValid: false
  function trackTick(x, y) {
    if (trail.length === 0 || Math.hypot(x - trailX, y - trailY) >= 3) {
      trail.push([x, y]);
      if (trail.length > 5000) trail.splice(0, 1000);
      trailX = x; trailY = y; trailDirty = true;
    }
    if (trackDist <= 0 && trackSecs <= 0) return;
    var now = Date.now(), due = false;
    if (!trkValid) due = true;
    else {
      if (trackDist > 0 && Math.hypot(x - trkX, y - trkY) >= trackDist) due = true;
      if (trackSecs > 0 && now - trkT >= trackSecs * 1000) due = true;
    }
    if (!due) return;
    trkX = x; trkY = y; trkT = now; trkValid = true;
    writeTrack(x, y);
  }
  function writeTrack(x, y) {
    var d = new Date();
    var stn = nav ? rnd(nav.stn, 1) : "", xt = nav ? rnd(nav.xtrack, 2) : "";
    var hd = Math.round(deg(heading));
    if (csvLog) {
      trackBuf.push([dateIso(d), timeIso(d), machineId, curLine, stn, xt, rnd(x, 2), rnd(y, 2), rnd(elev, 2), rnd(hdop, 1), rnd(speedKmh, 1), hd].map(csvCell).join(","));
      if (trackBuf.length >= 10) flushTrack();
    }
    var tl = layerByName(trackLayerName);
    if (tl) writePointLayer(tl, x, y, {Machine: machineId, Line: curLine, Stn: stn, XTrack: xt, Easting: rnd(x, 2), Northing: rnd(y, 2),
                                       Elev: rnd(elev, 2), Hdop: hdop, Speed: rnd(speedKmh, 1), Heading: hd, Time: d.toISOString()});
  }
  function flushTrack() {
    if (trackBuf.length === 0) return;
    var rows = trackBuf; trackBuf = [];
    if (!appendRows(logPath("Track"), trackHeader, rows)) trackBuf = rows.concat(trackBuf);
  }
  Timer { interval: 30000; repeat: true; running: true; onTriggered: plugin.flushTrack() }

  // ---- marks (features) ----
  readonly property var commonCodes: ["FENCE", "GATE", "TRACK", "CREEK", "DRAIN", "POWERLINE", "PIPELINE", "HAZARD", "CHECK", "DAM", "BORE", "WELL", "TANK", "MUSTER", "GRID", "ENTRY", "CROSSING", "ROAD", "TREE", "ROCK", "SOFT", "STOP"]
  property string lastComments: ""
  function recordMark(code, strNo, rem, quiet) {
    if (!haveFix) { if (!quiet) toast("No GPS fix"); return false; }
    var layer = layerByName(marksLayerName);
    if (!csvLog && !layer) { toast("NM: nothing to write to - tick 'Write CSV files' in the NM settings"); return false; }
    var d = new Date();
    var label = featureLabel(code, strNo);
    var stn = nav ? rnd(nav.stn, 1) : "", xt = nav ? rnd(nav.xtrack, 2) : "";
    var id = nextMarkId;
    if (csvLog) {
      var row = [id, dateIso(d), timeIso(d), machineId, code, strNo > 0 ? strNo : "", label, curLine, stn, xt, rnd(posX, 2), rnd(posY, 2), rnd(elev, 2), rnd(hdop, 1), rem].map(csvCell).join(",");
      if (!appendRows(logPath("Marks"), marksHeader, [row])) { toast("NM: mark NOT saved - " + csvStatus); return false; }
    }
    if (layer) writePointLayer(layer, posX, posY, {MarkID: id, Machine: machineId, Code: code, StringNo: strNo, Label: label, Line: curLine,
                                                    Stn: stn, XTrack: xt, Easting: rnd(posX, 2), Northing: rnd(posY, 2), Elev: rnd(elev, 2),
                                                    Hdop: hdop, Remarks: rem, Time: d.toISOString()});
    nextMarkId++;
    recWarn = false;
    recLabel = (label !== "" ? label : "MARK") + "  #" + id;
    recBannerTimer.restart();
    return true;
  }
  function streamPoint() {
    lastStreamX = posX; lastStreamY = posY;
    recordMark(lastCode, lastString, lastComments !== "" ? lastComments : "stream", true);
  }

  Connections {
    target: plugin.positioning
    function onPositionInformationChanged() { plugin.onPosition(); }
  }

  // ------------------------------------------------------------------ UI
  readonly property color cBg: "#E6101820"
  readonly property color cOk: "#35D07F"
  readonly property color cBad: "#FF4B4B"
  readonly property color cWarn: "#FFC833"
  readonly property color cText: "#F2F5F7"
  readonly property color cDim: "#8FA1AE"
  // On line = inside the crossline corridor (XTol)
  readonly property bool onLine: positioning.active && haveFix && nav !== null && Math.abs(nav.xtrack) <= xTol
  readonly property color cZone: zoneStat === "nogo" ? cBad : (zoneStat === "warn" ? "#FF9A1F" : "#1E7B46")

  // Position of the NM circle on screen, so the MARK button and readouts sit in a column directly under it
  property real launchX: -1
  property real launchY: -1
  function sideX(w) {
    var pw = mainWindow.contentItem.width;
    return Math.round(launchX >= 0 ? launchX + (launcher.width - w) / 2 : pw - w - 12);
  }
  function sideY(n, h) {
    var base = launchY >= 0 ? launchY + launcher.height : mainWindow.contentItem.height * 0.2;
    return Math.round(base + 10 + n * (h + 10));
  }
  Timer {
    interval: 400; repeat: true; running: true
    onTriggered: {
      try {
        var p = launcher.mapToItem(mainWindow.contentItem, 0, 0);
        if (!isNaN(p.x) && !isNaN(p.y) && (Math.abs(p.x - plugin.launchX) > 0.5 || Math.abs(p.y - plugin.launchY) > 0.5)) { plugin.launchX = p.x; plugin.launchY = p.y; }
      } catch (e) {}
    }
  }

  Rectangle {
    id: launcher
    width: 48; height: 48; radius: 24
    color: panel.visible ? "#1B6EF3" : "#80000000"
    Text { anchors.centerIn: parent; text: "NM"; color: "white"; font.bold: true; font.pixelSize: 15 }
    MouseArea { anchors.fill: parent
      onClicked: {
        panel.visible = !panel.visible;
        if (panel.visible && !plugin.loadedOnce && !plugin.loading) plugin.startLoad();
      } }
  }

  // stored-mark banner
  Timer { id: recBannerTimer; interval: 5000; repeat: false; onTriggered: plugin.recLabel = "" }
  Rectangle {
    id: recBanner
    parent: mainWindow.contentItem
    z: 102
    visible: plugin.recLabel !== "" && plugin.mapClear
    width: Math.min(parent.width - 24, recBannerText.implicitWidth + 40)
    height: 52; radius: 10
    x: Math.round((parent.width - width) / 2)
    y: panel.visible ? parent.height - height - (mainWindow.sceneBottomMargin || 0) - 130 : (mainWindow.sceneTopMargin || 0) + 8
    color: plugin.recWarn ? "#F0B26B00" : "#F0138A45"
    border.color: "white"; border.width: 2
    Text { id: recBannerText; anchors.centerIn: parent; text: "✓ " + plugin.recLabel; color: "white"; font.pixelSize: 24; font.bold: true }
    MouseArea { anchors.fill: parent; onClicked: plugin.recLabel = "" }
  }

  // advisory banner (yellow, as NavMini's advisory window)
  Rectangle {
    id: advBanner
    parent: mainWindow.contentItem
    z: 102
    visible: plugin.advText !== "" && plugin.mapClear && plugin.positioning.active
    width: Math.min(parent.width - 24, 520)
    height: advTxt.implicitHeight + 16
    radius: 8
    x: Math.round((parent.width - width) / 2)
    y: parent.height - height - (mainWindow.sceneBottomMargin || 0) - (panel.visible ? 70 : hud.height + 16)
    color: "#F0F2C21B"
    border.color: "#222222"; border.width: 2
    Text { id: advTxt; anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 8 }
      text: "⚠ " + plugin.advText; wrapMode: Text.Wrap; color: "#222222"; font.pixelSize: 17; font.bold: true }
  }

  // ---- MAIN SCREEN HUD (bottom centre, see-through so the map ahead stays visible):
  // GPS quality (Q1 good .. Q5 bad), left/right of line, closest station and START/STOP.
  // Everything else is behind the NM circle / gear.
  Rectangle {
    id: hud
    parent: mainWindow.contentItem
    z: 101
    visible: !panel.visible && plugin.mapClear
    readonly property bool compact: mainWindow.contentItem.width < 700
    readonly property real k: compact ? 0.85 : 1.0
    width: Math.min(mainWindow.contentItem.width - 12, compact ? 380 : 640)
    height: hudGrid.implicitHeight + 10
    x: Math.round((mainWindow.contentItem.width - width) / 2)
    y: mainWindow.contentItem.height - height - (mainWindow.sceneBottomMargin || 0) - 8
    radius: 10
    color: plugin.onLine ? "#58138A45" : "#58101820"
    border.color: "#50FFFFFF"; border.width: 1

    readonly property bool gpsOn: plugin.positioning.active
    readonly property int qNum: plugin.qualityNum()
    readonly property color qColor: (!gpsOn || !plugin.haveFix || qNum >= 4) ? plugin.cBad : (qNum === 3 ? plugin.cWarn : plugin.cOk)
    readonly property string qText: {
      if (!gpsOn) return "GPS OFF";
      if (!plugin.haveFix) return "NO FIX";
      return "Q" + qNum;
    }
    readonly property string qSub: {
      if (!gpsOn || !plugin.haveFix) return "";
      var s = "";
      if (plugin.hdop > 0) s = "HDOP " + plugin.fmt(plugin.hdop, 1);
      else if (plugin.hacc > 0) s = "H " + plugin.hacc.toFixed(2) + " m";
      if (plugin.qualDesc !== "" && !/unknown/i.test(plugin.qualDesc)) s += (s !== "" ? "  " : "") + plugin.qualDesc;
      return s;
    }

    GridLayout {
      id: hudGrid
      anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6 }
      columns: hud.compact ? 2 : 4
      columnSpacing: 8; rowSpacing: 4

      // --- GPS quality ---
      Row {
        Layout.fillWidth: true; Layout.preferredWidth: 1
        spacing: 7
        Rectangle { width: Math.round(18 * hud.k); height: width; radius: width / 2; color: hud.qColor; border.color: "white"; border.width: 1; anchors.verticalCenter: parent.verticalCenter }
        Column {
          anchors.verticalCenter: parent.verticalCenter
          Text { text: hud.qText; color: hud.qColor; font.pixelSize: Math.round(28 * hud.k); font.bold: true; style: Text.Outline; styleColor: "#000000" }
          Text { text: hud.qSub; visible: text !== ""; color: "#E6EDF2"; font.pixelSize: Math.round(10 * hud.k); style: Text.Outline; styleColor: "#000000"; width: Math.round(120 * hud.k); elide: Text.ElideRight }
        }
      }

      // --- left / right of the line ---
      Row {
        Layout.fillWidth: true; Layout.preferredWidth: 1
        spacing: 6
        Canvas {
          id: steer
          width: Math.round(38 * hud.k); height: width
          property real xt: plugin.nav ? plugin.nav.xtrack : NaN
          property bool locked: plugin.onLine
          onXtChanged: requestPaint()
          onLockedChanged: requestPaint()
          onWidthChanged: requestPaint()
          onPaint: {
            var c = getContext("2d"); c.reset();
            if (isNaN(xt)) return;
            var w = width, h = height;
            if (locked) {
              c.strokeStyle = plugin.cOk; c.lineWidth = 5;
              c.beginPath(); c.arc(w / 2, h / 2, w * 0.36, 0, 2 * Math.PI); c.stroke();
              return;
            }
            // arrow points the way to steer back to the line (position right of line -> steer left)
            var d = xt > 0 ? -1 : 1;
            c.fillStyle = plugin.cWarn; c.strokeStyle = "#000000"; c.lineWidth = 1.5;
            c.beginPath();
            c.moveTo(w / 2 + d * w * 0.46, h / 2);
            c.lineTo(w / 2 - d * w * 0.10, h / 2 - h * 0.40);
            c.lineTo(w / 2 - d * w * 0.10, h / 2 - h * 0.16);
            c.lineTo(w / 2 - d * w * 0.46, h / 2 - h * 0.16);
            c.lineTo(w / 2 - d * w * 0.46, h / 2 + h * 0.16);
            c.lineTo(w / 2 - d * w * 0.10, h / 2 + h * 0.16);
            c.lineTo(w / 2 - d * w * 0.10, h / 2 + h * 0.40);
            c.closePath(); c.fill(); c.stroke();
          }
        }
        Column {
          anchors.verticalCenter: parent.verticalCenter
          Text { text: "OFF LINE"; color: "#E6EDF2"; font.pixelSize: Math.round(10 * hud.k); style: Text.Outline; styleColor: "#000000" }
          Text {
            property real xt: plugin.nav ? plugin.nav.xtrack : NaN
            text: isNaN(xt) ? "--" : (xt > 0 ? "R " : (xt < 0 ? "L " : "")) + Math.abs(xt).toFixed(1) + " m"
            color: isNaN(xt) ? plugin.cDim : (Math.abs(xt) > plugin.xTol ? plugin.cBad : plugin.cOk)
            font.pixelSize: Math.round(28 * hud.k); font.bold: true; style: Text.Outline; styleColor: "#000000"
          }
        }
      }

      // --- closest station (tap to change line) ---
      Item {
        Layout.fillWidth: true; Layout.preferredWidth: 1
        implicitHeight: stnCol.implicitHeight
        Column {
          id: stnCol
          width: parent.width
          Text { text: "LINE " + (plugin.curLine === "" ? "- tap to pick" : plugin.curLine) + "  CLOSEST STN"; color: plugin.curLine === "" ? plugin.cWarn : "#E6EDF2"; font.pixelSize: Math.round(10 * hud.k); elide: Text.ElideRight; width: parent.width; style: Text.Outline; styleColor: "#000000" }
          Text { text: plugin.liveStnLabel(); color: "#8FC7FF"; font.pixelSize: Math.round(30 * hud.k); font.bold: true; style: Text.Outline; styleColor: "#000000" }
          Text { visible: plugin.streaming; text: "STREAMING MARKS"; color: "#FF6B6B"; font.pixelSize: Math.round(10 * hud.k); font.bold: true; style: Text.Outline; styleColor: "#000000" }
        }
        MouseArea { anchors.fill: parent; onClicked: linePopup.openPicker() }
      }

      // --- START / STOP ---
      Rectangle {
        Layout.fillWidth: true; Layout.preferredWidth: 1
        Layout.preferredHeight: Math.round(46 * hud.k)
        radius: 6
        color: plugin.positioning.active ? "#D9B3261E" : "#D91E7B46"
        border.color: "white"; border.width: 1
        Text { anchors.centerIn: parent; text: plugin.positioning.active ? "STOP" : "START"; color: "white"; font.bold: true; font.pixelSize: Math.round(20 * hud.k) }
        MouseArea { anchors.fill: parent; onClicked: plugin.startStop() }
      }
    }
  }

  // ---- MARK: feature code, string no, remarks; single point or stream ----
  Popup {
    id: markPopup
    parent: mainWindow.contentItem
    modal: true
    x: Math.round((parent.width - width) / 2)
    y: Math.round(parent.height * 0.12)
    width: Math.min(parent.width - 24, 400)
    height: fcCol.implicitHeight + 28
    function openIt() {
      if (!plugin.haveFix) { plugin.toast("No GPS fix"); return; }
      fcCode.editText = plugin.lastCode;
      fcStr.text = plugin.lastString > 0 ? plugin.lastString : "";
      fcRem.text = "";
      open();
    }
    ColumnLayout {
      id: fcCol
      width: parent.width
      spacing: 6
      Text { text: "Mark feature"; font.bold: true; font.pixelSize: 17 }
      Text { text: "Feature code / string no. (0 or blank = single point)"; wrapMode: Text.Wrap; Layout.fillWidth: true; font.pixelSize: 12 }
      RowLayout { Layout.fillWidth: true
        ComboBox { id: fcCode; Layout.fillWidth: true; editable: true; model: plugin.commonCodes
          onActivated: editText = currentText }
        TextField { id: fcStr; Layout.preferredWidth: 90; placeholderText: "String"; inputMethodHints: Qt.ImhDigitsOnly } }
      TextField { id: fcRem; Layout.fillWidth: true; placeholderText: "Remarks / comment"; maximumLength: 200 }
      RowLayout { Layout.fillWidth: true
        Button { Layout.fillWidth: true; text: "Cancel"; onClicked: markPopup.close() }
        Button { Layout.fillWidth: true; text: "Write"
          onClicked: {
            var code = fcCode.editText;
            var strNo = parseInt(fcStr.text || "0");
            plugin.lastCode = code; plugin.lastString = isNaN(strNo) ? 0 : strNo;
            plugin.recordMark(code, plugin.lastString, fcRem.text, false);
            markPopup.close();
          } } }
      Button { Layout.fillWidth: true; text: "Start Stream (write every " + plugin.streamInterval + " m)"
        onClicked: {
          var code2 = fcCode.editText;
          var strNo2 = parseInt(fcStr.text || "0");
          plugin.lastCode = code2; plugin.lastString = isNaN(strNo2) ? 0 : strNo2;
          plugin.lastComments = fcRem.text;
          plugin.streamPoint();
          plugin.streaming = true;
          markPopup.close();
          plugin.toast("Streaming every " + plugin.streamInterval + " m. Tap the red STOP button to end it.");
        } }
    }
  }

  // Full-screen RED (no-go) / ORANGE (warning) highlight while inside a zone
  Rectangle {
    id: zoneFrame
    parent: mainWindow.contentItem
    anchors.fill: parent
    z: 100
    visible: plugin.mapClear && positioning.active && (plugin.zoneStat === "nogo" || plugin.zoneStat === "warn")
    color: plugin.zoneStat === "nogo" ? "#40FF1F1F" : "#38FF9A1F"
    border.color: plugin.zoneStat === "nogo" ? "#FF1F1F" : "#FF9A1F"
    border.width: 18
  }

  // Full-screen green highlight while inside the XTol corridor (touches pass straight through to the map)
  Rectangle {
    id: onLineFrame
    parent: mainWindow.contentItem
    anchors.fill: parent
    z: 99
    visible: plugin.mapClear && plugin.onLine && plugin.zoneStat === "clear"
    color: "#2635D07F"
    border.color: "#35D07F"
    border.width: 14
  }

  // Red track trail (NavMini draws the day's track as a red vector)
  Item {
    id: trailLayer
    parent: mainWindow.contentItem
    anchors.fill: parent
    z: 88
    enabled: false
    visible: plugin.mapClear && plugin.showTrail && plugin.positioning.active && plugin.trail.length > 1
    Timer { interval: 500; repeat: true; running: trailLayer.visible
      onTriggered: { if (plugin.trailDirty || true) { plugin.trailDirty = false; trailCv.requestPaint(); } } }
    onVisibleChanged: if (visible) trailCv.requestPaint()
    Canvas {
      id: trailCv
      anchors.fill: parent
      onPaint: {
        var ctx = getContext("2d");
        ctx.reset();
        var t = plugin.trail, n = t.length;
        if (n < 2) return;
        try {
          var ms = plugin.mapCanvas.mapSettings;
          var from = Math.max(0, n - 600);
          ctx.lineWidth = 3.5; ctx.lineJoin = "round"; ctx.lineCap = "round";
          ctx.strokeStyle = "#D62020";
          ctx.beginPath();
          for (var i = from; i < n; i++) {
            var p = ms.coordinateToScreen(QfGeometryUtils.point(t[i][0], t[i][1]));
            p = plugin.mapCanvas.mapToItem(trailCv, p.x, p.y);
            if (i === from) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
          }
          ctx.stroke();
        } catch (e) {}
      }
    }
  }

  Rectangle {
    id: panel
    parent: mainWindow.contentItem
    visible: false
    opacity: plugin.mapClear ? 1 : 0
    enabled: plugin.mapClear
    z: 100
    x: 4
    y: (mainWindow.sceneTopMargin || 0) + 92
    width: parent.width - 8
    height: col.implicitHeight + 12
    radius: 8
    color: plugin.onLine ? "#F0138A45" : plugin.cBg

    Rectangle {
      z: 5
      anchors { top: parent.top; right: parent.right; margins: 4 }
      width: 30; height: 30; radius: 15
      color: "#40FFFFFF"
      Text { anchors.centerIn: parent; text: "X"; color: "white"; font.pixelSize: 14 }
      MouseArea { anchors.fill: parent; onClicked: panel.visible = false }
    }

    ColumnLayout {
      id: col
      anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6 }
      spacing: 4

      // GNSS strip: HDOP, H accuracy, satellites, speed
      RowLayout {
        Layout.fillWidth: true
        Layout.rightMargin: 34
        spacing: 10
        Repeater {
          model: [
            {t: "HDOP", v: plugin.hdop > 0 ? plugin.fmt(plugin.hdop, 1) : "--", bad: plugin.qBad()},
            {t: "H (m)", v: plugin.hacc > 0 ? plugin.hacc.toFixed(2) : "--", bad: false},
            {t: "SATS", v: plugin.nSats > 0 ? String(plugin.nSats) : "--", bad: false},
            {t: "km/h", v: plugin.fmt(plugin.speedKmh, 0), bad: false}
          ]
          delegate: ColumnLayout {
            Layout.fillWidth: true; Layout.preferredWidth: 1; spacing: 0
            Text { text: modelData.t; color: plugin.cDim; font.pixelSize: 10 }
            Text {
              text: modelData.v; font.pixelSize: 20; font.bold: true
              color: !plugin.haveFix ? plugin.cBad : (modelData.bad ? plugin.cBad : plugin.cOk)
            }
          }
        }
      }

      Text {
        Layout.fillWidth: true
        Layout.rightMargin: 34
        elide: Text.ElideRight
        text: plugin.haveFix ? (plugin.qualDesc !== "" ? plugin.qualDesc : "FIX") : "NO FIX"
        font.pixelSize: 15; font.bold: true
        color: !plugin.haveFix ? plugin.cBad
             : (/fix/i.test(plugin.qualDesc) && !/float/i.test(plugin.qualDesc) ? plugin.cOk : plugin.cWarn)
      }

      // zone status bar: green clear / orange warning / red no-go
      Rectangle {
        id: zoneBar
        Layout.fillWidth: true
        Layout.rightMargin: 34
        height: 32; radius: 4
        color: plugin.cZone
        SequentialAnimation on opacity {
          running: plugin.zoneStat !== "clear"
          loops: Animation.Infinite
          NumberAnimation { to: 0.5; duration: 350 }
          NumberAnimation { to: 1.0; duration: 350 }
          onRunningChanged: if (!running) zoneBar.opacity = 1.0
        }
        Text {
          anchors.fill: parent; anchors.margins: 4
          verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight
          font.bold: true; font.pixelSize: 14; color: "white"
          text: plugin.zoneStat === "nogo" ? "⚠ NO-GO: " + plugin.nogoHits.join(", ")
              : (plugin.zoneStat === "warn" ? "⚠ WARNING: " + plugin.warnHits.join(", ") : "ZONES CLEAR")
        }
      }

      Text {
        Layout.fillWidth: true
        visible: plugin.advText !== ""
        text: "⚠ " + plugin.advText
        wrapMode: Text.Wrap; font.pixelSize: 14; font.bold: true; color: "#222222"
        Rectangle { z: -1; anchors.fill: parent; anchors.margins: -2; color: "#F2C21B"; radius: 4 }
      }

      // line readouts
      RowLayout {
        Layout.fillWidth: true
        spacing: 8
        Repeater {
          model: [
            {t: "LINE", v: plugin.curLine === "" ? "--" : plugin.curLine},
            {t: "FROM → TO", v: plugin.nav ? (plugin.nav.fromStn + "→" + plugin.nav.toStn) : "--"},
            {t: "TO STN " + (plugin.nav ? plugin.nav.targetStn : "--"), v: plugin.nav ? plugin.fmt(plugin.nav.atrack, 1) : "--"},
            {t: "TO END", v: plugin.nav ? plugin.fmt(plugin.nav.toEnd, 0) : "--"}
          ]
          delegate: ColumnLayout {
            Layout.fillWidth: true; spacing: 0
            Text { text: modelData.t; color: plugin.cDim; font.pixelSize: 11 }
            Text { text: modelData.v; color: plugin.cText; font.pixelSize: 22; font.bold: true }
          }
        }
      }

      // cross track + arrow back to the line
      RowLayout {
        Layout.fillWidth: true
        spacing: 10
        Item {
          width: 54; height: 54
          visible: plugin.nav !== null
          Canvas {
            id: arrow
            anchors.fill: parent
            property real ang: plugin.nav
              ? plugin.wrapPi(plugin.bearing(plugin.posX, plugin.posY, plugin.nav.foot[0], plugin.nav.foot[1]) - plugin.nav.travelBearing)
              : 0
            property bool locked: plugin.onLine
            onAngChanged: requestPaint()
            onLockedChanged: requestPaint()
            onPaint: {
              var c = getContext("2d"); c.reset();
              if (locked) {
                c.strokeStyle = plugin.cOk; c.lineWidth = 6;
                c.beginPath(); c.arc(width / 2, height / 2, 20, 0, 2 * Math.PI); c.stroke();
                return;
              }
              c.translate(width / 2, height / 2); c.rotate(ang);
              c.fillStyle = plugin.cWarn;
              c.beginPath(); c.moveTo(0, -22); c.lineTo(14, 8); c.lineTo(0, 2); c.lineTo(-14, 8); c.closePath(); c.fill();
            }
          }
        }
        ColumnLayout {
          spacing: 0
          Text { text: "XTRACK"; color: plugin.cDim; font.pixelSize: 11 }
          Text {
            property real xt: plugin.nav ? plugin.nav.xtrack : NaN
            text: isNaN(xt) ? "--" : (xt > 0 ? "R " : (xt < 0 ? "L " : "")) + Math.abs(xt).toFixed(1) + " m"
            font.pixelSize: 38; font.bold: true
            color: isNaN(xt) ? plugin.cDim : (Math.abs(xt) > plugin.xTol ? plugin.cBad : plugin.cOk)
          }
        }
        Item { Layout.fillWidth: true }
        ColumnLayout {
          spacing: 0
          Text { text: plugin.haveFix ? "E " + plugin.fmt(plugin.posX, 1) + "  N " + plugin.fmt(plugin.posY, 1) : ""; color: plugin.cDim; font.pixelSize: 11; Layout.alignment: Qt.AlignRight }
          Text { text: plugin.clockText + "   " + plugin.nmVersion; color: plugin.cDim; font.pixelSize: 11; Layout.alignment: Qt.AlignRight }
        }
      }

      Text {
        Layout.fillWidth: true
        visible: plugin.statusText !== ""
        text: plugin.statusText
        wrapMode: Text.Wrap; font.pixelSize: 12
        color: plugin.statusText.indexOf("ERROR") >= 0 ? plugin.cBad : plugin.cDim
      }

      // buttons
      Repeater {
        model: [
          [
            {t: plugin.positioning.active ? "STOP" : "START", c: plugin.positioning.active ? "#B3261E" : "#1E7B46", a: "startstop"},
            {t: "LINE", c: "#2B3A47", a: "line"},
            {t: plugin.dir > 0 ? "DIR +" : "DIR −", c: "#2B3A47", a: "dir"},
            {t: plugin.streaming ? "STREAM ●" : "MARK", c: plugin.streaming ? "#B3261E" : "#C2610C", a: "mark"}
          ],
          [
            {t: plugin.navView ? "NAV" : "MAP", c: "#2B3A47", a: "view"},
            {t: plugin.follow ? "FOLLOW" : "FREE", c: plugin.follow ? "#1E7B46" : "#2B3A47", a: "follow"},
            {t: plugin.showTrail ? "TRAIL" : "NO TRAIL", c: plugin.showTrail ? "#8B1A1A" : "#2B3A47", a: "trail"},
            {t: "⚙", c: "#2B3A47", a: "cfg"}
          ]
        ]
        delegate: RowLayout {
          Layout.fillWidth: true
          spacing: 4
          Repeater {
            model: modelData
            delegate: Rectangle {
              Layout.fillWidth: true
              Layout.preferredHeight: 44
              radius: 6
              color: modelData.c
              Text { anchors.centerIn: parent; text: modelData.t; color: "white"; font.bold: true; font.pixelSize: 12 }
              MouseArea {
                anchors.fill: parent
                onClicked: {
                  try {
                    switch (modelData.a) {
                    case "startstop": plugin.startStop(); break;
                    case "line": linePopup.openPicker(); break;
                    case "dir": plugin.toggleDir(); break;
                    case "mark":
                      if (plugin.streaming) { plugin.streaming = false; plugin.toast("Stream stopped"); }
                      else markPopup.openIt();
                      break;
                    case "follow": plugin.follow = !plugin.follow; plugin.lastCx = NaN; plugin.lastRot = NaN; if (plugin.follow && plugin.haveFix) { mapCanvas.mapSettings.center = QfGeometryUtils.point(plugin.posX, plugin.posY); plugin.lastCx = plugin.posX; plugin.lastCy = plugin.posY; } break;
                    case "view": plugin.navView = !plugin.navView; plugin.saveSettings(); break;
                    case "trail": plugin.showTrail = !plugin.showTrail; plugin.saveSettings(); break;
                    case "cfg": cfgPopup.open(); break;
                    }
                  } catch (e) { plugin.statusText = "ERROR: " + e; plugin.toast("NM: " + e); }
                }
              }
            }
          }
        }
      }
    }
  }

  // ---- LINE picker (Change Line) ----
  Popup {
    id: linePopup
    parent: mainWindow.contentItem
    modal: true
    x: Math.round((parent.width - width) / 2)
    y: Math.round((parent.height - height) / 2)
    width: Math.min(parent.width - 40, 380)
    height: Math.min(parent.height - 80, 520)
    property var items: []
    function openPicker() {
      if (!plugin.loadedOnce) {
        plugin.pendingPicker = true;
        if (!plugin.loading) plugin.startLoad();
        plugin.toast(plugin.loading ? "Loading preplot... the line list opens when ready" : "Could not load layers");
        return;
      }
      var arr;
      if (plugin.haveFix) arr = plugin.nearestLines(plugin.lines, plugin.posX, plugin.posY, 0);
      else { arr = []; for (var id in plugin.lines) arr.push({id: id, off: NaN}); }
      items = arr; open();
    }
    ColumnLayout {
      anchors.fill: parent
      Text { text: "Change line" + (plugin.haveFix ? " (nearest first)" : ""); font.bold: true; font.pixelSize: 16 }
      ListView {
        Layout.fillWidth: true; Layout.fillHeight: true
        clip: true
        model: linePopup.items
        delegate: ItemDelegate {
          width: ListView.view.width
          text: "Line " + modelData.id + (isNaN(modelData.off) ? "" : "   —   " + modelData.off.toFixed(0) + " m away")
          onClicked: { plugin.setLine(modelData.id); linePopup.close(); }
        }
      }
    }
  }

  // ---- position marker: own symbol + bearing line drawn on the map ----
  readonly property var symIds: ["default", "arrow", "cross", "dot", "wd", "ute", "truck", "tractor", "skid"]
  readonly property var symNames: ["QField default (none)", "Arrow", "Crosshair", "Dot + cone", "4WD", "Ute", "Truck", "Tractor", "Skid steer"]
  readonly property var colNames: ["Red", "Orange", "Yellow", "Green", "Blue", "Magenta", "Black", "White"]
  readonly property var colHex: ["#E24B4A", "#EF7B1A", "#F2C21B", "#3FA34D", "#2F7FE0", "#D4379E", "#222222", "#FFFFFF"]
  readonly property var sizeNames: ["Small", "Medium", "Large", "Extra large"]
  readonly property var sizePx: [28, 42, 60, 84]
  readonly property var lenNames: ["Off", "500 m", "1 km", "2 km", "5 km", "10 km", "20 km"]
  readonly property var lenM: [0, 500, 1000, 2000, 5000, 10000, 20000]
  property string markerSym: "default"
  property string markerCol: "Red"
  property real markerSize: 60
  property real bearLen: 0
  property string lineStyle: "Solid"
  property string lineCol: "Same as symbol"
  readonly property var lineColNames: ["Same as symbol", "Red", "Orange", "Yellow", "Green", "Blue", "Magenta", "Black", "White"]

  Item {
    id: markerLayer
    parent: mainWindow.contentItem
    anchors.fill: parent
    z: 90
    enabled: false
    visible: plugin.mapClear && positioning.active && plugin.haveFix && (plugin.markerSym !== "default" || plugin.bearLen > 0)
    property real sx: -1000
    property real sy: -1000
    property real ex: -1000
    property real ey: -1000
    property real angDeg: 0
    readonly property color mainCol: {
      var i = plugin.colNames.indexOf(plugin.markerCol);
      var c = plugin.colHex[i < 0 ? 0 : i];
      return (c === "#FFFFFF") ? "#888888" : c;
    }

    readonly property color lineColor: {
      var i = plugin.colNames.indexOf(plugin.lineCol);
      if (i < 0) return mainCol;
      var c = plugin.colHex[i];
      return (c === "#FFFFFF") ? "#888888" : c;
    }

    function update() {
      try {
        var ms = plugin.mapCanvas.mapSettings;
        var b = plugin.heading;
        var rot = 0;
        try { rot = ms.rotation; if (!isFinite(rot)) rot = 0; } catch (er) { rot = 0; }
        var p, q = null;
        try {
          p = ms.coordinateToScreen(QfGeometryUtils.point(plugin.posX, plugin.posY));
          if (plugin.bearLen > 0)
            q = ms.coordinateToScreen(QfGeometryUtils.point(plugin.posX + plugin.bearLen * Math.sin(b), plugin.posY + plugin.bearLen * Math.cos(b)));
          p = plugin.mapCanvas.mapToItem(markerLayer, p.x, p.y);
          if (q) q = plugin.mapCanvas.mapToItem(markerLayer, q.x, q.y);
        } catch (ec) {
          // no coordinate transform on this QField build: the N25 follow keeps the position at the centre of the map
          p = { x: width / 2, y: height / 2 };
          q = null;
          if (plugin.bearLen > 0) { var a = b * 180 / Math.PI + rot; q = { x: p.x + 4000 * Math.sin(a * Math.PI / 180), y: p.y - 4000 * Math.cos(a * Math.PI / 180) }; }
        }
        var ang = b * 180 / Math.PI + rot;
        var moved = Math.abs(p.x - sx) > 0.4 || Math.abs(p.y - sy) > 0.4 || Math.abs(ang - angDeg) > 0.3;
        var qex = q ? q.x : -1000, qey = q ? q.y : -1000;
        if (Math.abs(qex - ex) > 0.4 || Math.abs(qey - ey) > 0.4) moved = true;
        sx = p.x; sy = p.y; ex = qex; ey = qey; angDeg = ang;
        if (moved) { symCv.requestPaint(); lineCv.requestPaint(); }
      } catch (e) {}
    }
    onVisibleChanged: if (visible) { update(); symCv.requestPaint(); lineCv.requestPaint(); }

    Timer { interval: 120; repeat: true; running: markerLayer.visible; onTriggered: markerLayer.update() }

    Canvas {
      id: lineCv
      anchors.fill: parent
      visible: plugin.bearLen > 0
      onPaint: {
        var ctx = getContext("2d");
        ctx.reset();
        if (plugin.bearLen <= 0 || markerLayer.ex < -999) return;
        var x0 = markerLayer.sx, y0 = markerLayer.sy;
        var dx = markerLayer.ex - x0, dy = markerLayer.ey - y0;
        var full = Math.sqrt(dx * dx + dy * dy);
        if (full < 1) return;
        var k = full > 6000 ? 6000 / full : 1;
        var x1 = x0 + dx * k, y1 = y0 + dy * k;
        ctx.lineCap = "round";
        ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 7;
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
        ctx.strokeStyle = markerLayer.lineColor; ctx.lineWidth = 3.5;
        try { if (plugin.lineStyle === "Dashed") ctx.setLineDash([14, 9]); } catch (ed) {}
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
        try { ctx.setLineDash([]); } catch (ed2) {}
        // arrow head at the end of the line (only when the end of the line is on the screen)
        if (k === 1 && x1 > 0 && y1 > 0 && x1 < width && y1 < height) {
          var ux = dx / full, uy = dy / full, hl = 20, hw = 10;
          var bx = x1 - ux * hl, by = y1 - uy * hl;
          ctx.beginPath(); ctx.moveTo(x1 + ux * 3, y1 + uy * 3); ctx.lineTo(bx - uy * hw, by + ux * hw); ctx.lineTo(bx + uy * hw, by - ux * hw); ctx.closePath();
          ctx.lineJoin = "round"; ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 3; ctx.stroke();
          ctx.fillStyle = markerLayer.lineColor; ctx.fill();
          ctx.strokeStyle = "#222222"; ctx.lineWidth = 1; ctx.stroke();
        }
        var ticks = [500, 1000, 2000, 5000, 10000, 20000];
        ctx.font = "bold 12px sans-serif";
        for (var i = 0; i < ticks.length; i++) {
          if (ticks[i] > plugin.bearLen) break;
          var f = ticks[i] / plugin.bearLen;
          var tx = x0 + dx * f, ty = y0 + dy * f;
          if (tx < 0 || ty < 0 || tx > width || ty > height) continue;
          ctx.fillStyle = "#FFFFFF"; ctx.strokeStyle = "#222222"; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(tx, ty, 3.5, 0, 6.2832); ctx.fill(); ctx.stroke();
          var lbl = ticks[i] >= 1000 ? (ticks[i] / 1000) + " km" : ticks[i] + " m";
          ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 3; ctx.strokeText(lbl, tx + 7, ty - 5);
          ctx.fillStyle = "#222222"; ctx.fillText(lbl, tx + 7, ty - 5);
        }
      }
    }

    Canvas {
      id: symCv
      visible: plugin.markerSym !== "default"
      width: Math.round(plugin.markerSize * 1.3) + 6
      height: width
      x: markerLayer.sx - width / 2
      y: markerLayer.sy - height / 2
      onWidthChanged: requestPaint()
      property string sig: plugin.markerSym + plugin.markerCol
      onSigChanged: requestPaint()

      function rr(ctx, x, y, w, h, r) {
        ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
        ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r); ctx.lineTo(x + r, y + h);
        ctx.arcTo(x, y + h, x, y + h - r, r); ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r); ctx.closePath();
      }
      function box(ctx, x, y, w, h, r, fill, fa, stroke, sw) {
        rr(ctx, x, y, w, h, r);
        if (fill) { ctx.globalAlpha = fa; ctx.fillStyle = fill; ctx.fill(); }
        if (stroke) { ctx.globalAlpha = 1; ctx.strokeStyle = stroke; ctx.lineWidth = sw; ctx.stroke(); }
        ctx.globalAlpha = 1;
      }
      function ln(ctx, x1, y1, x2, y2, col, a, w) {
        ctx.globalAlpha = a; ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = "butt";
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.globalAlpha = 1;
      }
      function poly(ctx, pts, fill, stroke, sw) {
        ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
        for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath(); ctx.lineJoin = "round";
        if (fill) { ctx.fillStyle = fill; ctx.fill(); }
        if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = sw; ctx.stroke(); }
      }
      function circ(ctx, x, y, r, fill, stroke, sw) {
        ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832);
        if (fill) { ctx.fillStyle = fill; ctx.fill(); }
        if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = sw; ctx.stroke(); }
      }
      function drawSym(ctx, id, c) {
        var K = "#222222", W = "#FFFFFF", i, y;
        if (id === "arrow") {
          var ap = [[0, -46], [30, 38], [0, 20], [-30, 38]];
          poly(ctx, ap, c, W, 5); poly(ctx, ap, c, K, 1.5);
        } else if (id === "cross") {
          circ(ctx, 0, 0, 36, W, c, 7);
          ln(ctx, 0, -30, 0, 30, c, 1, 5); ln(ctx, -30, 0, 30, 0, c, 1, 5);
          poly(ctx, [[0, -50], [-9, -38], [9, -38]], c, K, 1.5);
        } else if (id === "dot") {
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-26, -46);
          ctx.arc(0, 0, 52.8, Math.atan2(-46, -26), Math.atan2(-46, 26), false); ctx.closePath();
          ctx.globalAlpha = 0.35; ctx.fillStyle = c; ctx.fill(); ctx.globalAlpha = 1;
          circ(ctx, 0, 0, 13, c, W, 5); circ(ctx, 0, 0, 13, null, K, 1.2);
        } else if (id === "wd") {
          box(ctx, -27, -30, 9, 20, 3, K, 1); box(ctx, 18, -30, 9, 20, 3, K, 1); box(ctx, -27, 16, 9, 20, 3, K, 1); box(ctx, 18, 16, 9, 20, 3, K, 1);
          box(ctx, -21, -44, 42, 90, 11, c, 1, K, 2);
          box(ctx, -15, -26, 30, 13, 3, W, 0.85); box(ctx, -15, 30, 30, 9, 3, W, 0.6);
          box(ctx, -14, -8, 28, 34, 3, null, 0, "#80222222", 2);
          ln(ctx, -14, 2, 14, 2, K, 0.5, 2); ln(ctx, -14, 14, 14, 14, K, 0.5, 2);
        } else if (id === "ute") {
          box(ctx, -27, -32, 9, 20, 3, K, 1); box(ctx, 18, -32, 9, 20, 3, K, 1); box(ctx, -27, 20, 9, 20, 3, K, 1); box(ctx, 18, 20, 9, 20, 3, K, 1);
          box(ctx, -21, -46, 42, 50, 11, c, 1, K, 2);
          box(ctx, -15, -30, 30, 12, 3, W, 0.85); box(ctx, -15, -12, 30, 12, 3, W, 0.55);
          box(ctx, -21, 6, 42, 42, 3, c, 0.45, K, 2);
          ctx.globalAlpha = 0.35; ctx.fillStyle = K; ctx.fillRect(-15, 12, 30, 30); ctx.globalAlpha = 1;
        } else if (id === "truck") {
          box(ctx, -27, -38, 9, 16, 3, K, 1); box(ctx, 18, -38, 9, 16, 3, K, 1); box(ctx, -27, 10, 9, 16, 3, K, 1);
          box(ctx, 18, 10, 9, 16, 3, K, 1); box(ctx, -27, 30, 9, 16, 3, K, 1); box(ctx, 18, 30, 9, 16, 3, K, 1);
          box(ctx, -20, -48, 40, 34, 8, c, 1, K, 2); box(ctx, -14, -40, 28, 11, 3, W, 0.85);
          box(ctx, -21, -10, 42, 58, 3, c, 0.55, K, 2);
          ln(ctx, -21, 8, 21, 8, K, 0.5, 2); ln(ctx, -21, 28, 21, 28, K, 0.5, 2);
        } else if (id === "tractor") {
          ln(ctx, -36, -38, 36, -38, K, 1, 3);
          box(ctx, -44, -50, 10, 24, 4, K, 1); box(ctx, 34, -50, 10, 24, 4, K, 1);
          box(ctx, -7, -46, 14, 38, 3, c, 1, K, 2); box(ctx, -13, -10, 26, 22, 3, c, 1, K, 2);
          box(ctx, -34, 4, 12, 46, 4, K, 1); box(ctx, 22, 4, 12, 46, 4, K, 1);
          box(ctx, -21, 8, 42, 42, 8, c, 1, K, 2);
          box(ctx, -14, 15, 28, 28, 6, W, 0.9, K, 2);
        } else if (id === "skid") {
          box(ctx, -36, -32, 14, 70, 5, K, 1); box(ctx, 22, -32, 14, 70, 5, K, 1);
          for (y = -26; y <= 34; y += 7) { ln(ctx, -36, y, -22, y, W, 0.35, 1.5); ln(ctx, 22, y, 36, y, W, 0.35, 1.5); }
          box(ctx, -23, -16, 46, 54, 5, c, 1, K, 2);
          box(ctx, -19, -38, 6, 34, 2, K, 0.8); box(ctx, 13, -38, 6, 34, 2, K, 0.8);
          box(ctx, -14, -6, 28, 28, 4, W, 0.85, K, 2);
          ln(ctx, -14, 30, 14, 30, K, 0.5, 2); ln(ctx, -14, 35, 14, 35, K, 0.5, 2);
          box(ctx, -42, -52, 84, 16, 3, c, 1, K, 2); ln(ctx, -42, -44, 42, -44, K, 0.4, 1.5);
        }
      }
      onPaint: {
        var ctx = getContext("2d");
        ctx.reset();
        if (plugin.markerSym === "default") return;
        var ci = plugin.colNames.indexOf(plugin.markerCol);
        var col = plugin.colHex[ci < 0 ? 0 : ci];
        if (col === "#FFFFFF" && plugin.markerSym === "cross") col = "#888888";
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.rotate(markerLayer.angDeg * Math.PI / 180);
        var s = plugin.markerSize / 100;
        ctx.scale(s, s);
        drawSym(ctx, plugin.markerSym, col);
        ctx.restore();
      }
    }
  }

  // ---- settings ----
  function configure() { cfgPopup.open(); }

  Popup {
    id: cfgPopup
    parent: mainWindow.contentItem
    modal: true
    x: Math.round((parent.width - width) / 2)
    y: Math.round((parent.height - height) / 2)
    width: Math.min(parent.width - 24, 400)
    height: Math.min(parent.height - 60, 600)
    onAboutToShow: {
      sX.text = plugin.xTol; sF.text = plugin.fromToThreshold; sInc.text = plugin.autoInc; sOff.text = plugin.machOffset;
      sTD.text = plugin.trackDist; sTS.text = plugin.trackSecs; sQ.text = plugin.qTol; sStr.text = plugin.streamInterval;
      sMid.text = plugin.machineId; sPre.text = plugin.preplotName; sStnF.text = plugin.stationField; sLnF.text = plugin.lineField;
      sAdvL.text = plugin.advLayerName; sAdvF.text = plugin.advField; sAdvD.text = plugin.advDist;
      sTrkL.text = plugin.trackLayerName; sMkL.text = plugin.marksLayerName;
      sSnd.checked = plugin.alarmSound; sCsv.checked = plugin.csvLog; sTr.checked = plugin.showTrail; sAuto.checked = plugin.autoPickLine;
      sMkSym.currentIndex = Math.max(0, plugin.symIds.indexOf(plugin.markerSym));
      sMkCol.currentIndex = Math.max(0, plugin.colNames.indexOf(plugin.markerCol));
      var szi = 0, szd = 1e9; for (var zi = 0; zi < plugin.sizePx.length; zi++) { var dz = Math.abs(plugin.sizePx[zi] - plugin.markerSize); if (dz < szd) { szd = dz; szi = zi; } }
      sMkSize.currentIndex = szi;
      sBearLen.currentIndex = Math.max(0, plugin.lenM.indexOf(plugin.bearLen));
      sLineSt.currentIndex = plugin.lineStyle === "Dashed" ? 1 : 0;
      sLineCol.currentIndex = Math.max(0, plugin.lineColNames.indexOf(plugin.lineCol));
    }
    ScrollView {
      id: cfgScroll
      anchors.fill: parent
      contentWidth: availableWidth
      clip: true
      GridLayout {
        width: cfgScroll.availableWidth
        columns: 2
        Text { text: "NM settings"; font.bold: true; font.pixelSize: 16; Layout.columnSpan: 2 }
        Text { Layout.columnSpan: 2; Layout.fillWidth: true; wrapMode: Text.Wrap; font.pixelSize: 11
          color: plugin.store ? "#1E7B46" : "#B3261E"
          text: plugin.store ? "Settings are remembered between sessions (per project)." : "Settings can NOT be remembered on this QField: " + plugin.storeErr }
        Text { text: "XTol - on-line corridor (m)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sX; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "From/To threshold (m)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sF; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "AutoInc (+1 / -1)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sInc; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "Machine offset (m, + ahead of antenna)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sOff; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "Track every (m), 0 = off"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sTD; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "Track every (s), 0 = off"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sTS; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "HDOP limit (0 = off)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sQ; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "MARK stream interval (m)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sStr; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "Machine ID (e.g. DOZER1)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sMid; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Preplot layer (blank = auto)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sPre; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Station field (blank = auto)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sStnF; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Line field (blank = auto)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sLnF; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Advisory layer (blank = none)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sAdvL; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Advisory text field (blank = auto)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sAdvF; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Advisory distance (m)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sAdvD; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; inputMethodHints: Qt.ImhFormattedNumbersOnly }
        Text { text: "Track points layer (optional)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sTrkL; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        Text { text: "Marks layer (optional)"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } TextField { id: sMkL; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; }
        CheckBox { id: sAuto; text: "Auto-pick nearest line (off = LINE button only)"; Layout.columnSpan: 2 }
        CheckBox { id: sSnd; text: "Alarm sounds"; Layout.columnSpan: 2 }
        CheckBox { id: sCsv; text: "Write CSV files (track + marks) beside the project"; Layout.columnSpan: 2 }
        CheckBox { id: sTr; text: "Show red track trail on the map"; Layout.columnSpan: 2 }
        Text { Layout.columnSpan: 2; Layout.fillWidth: true; wrapMode: Text.Wrap; font.pixelSize: 11
          color: plugin.soundOk ? "#1E7B46" : "#B3261E"
          text: (plugin.soundOk ? "Alarm sound files loaded." : "Sound files NOT loaded - the .wav files must sit next to this plugin file.")
                + "  " + plugin.csvStatus + "  [" + plugin.nmVersion + " build]" }
        Text { text: "Position marker (drawn on the map)"; font.bold: true; Layout.columnSpan: 2 }
        Text { text: "Symbol"; Layout.fillWidth: true; Layout.preferredWidth: 60 } ComboBox { id: sMkSym; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; model: plugin.symNames }
        Text { text: "Colour"; Layout.fillWidth: true; Layout.preferredWidth: 60 } ComboBox { id: sMkCol; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; model: plugin.colNames }
        Text { text: "Size"; Layout.fillWidth: true; Layout.preferredWidth: 60 } ComboBox { id: sMkSize; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; model: plugin.sizeNames }
        Text { text: "Bearing line length"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } ComboBox { id: sBearLen; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; model: plugin.lenNames }
        Text { text: "Bearing line colour"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } ComboBox { id: sLineCol; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; model: plugin.lineColNames }
        Text { text: "Bearing line style"; Layout.fillWidth: true; Layout.preferredWidth: 60; wrapMode: Text.Wrap } ComboBox { id: sLineSt; Layout.fillWidth: true; Layout.preferredWidth: 40; Layout.minimumWidth: 120; model: ["Solid", "Dashed"] }
        Button { text: "Reload layers"; Layout.fillWidth: true
          onClicked: { plugin.loadedOnce = false; plugin.startLoad(); } }
        Button { text: "Apply"; Layout.fillWidth: true
          onClicked: {
            function num(t, d) { var v = parseFloat(t); return isNaN(v) ? d : v; }
            plugin.xTol = num(sX.text, 5); plugin.fromToThreshold = num(sF.text, 5); plugin.autoInc = parseInt(sInc.text) < 0 ? -1 : 1;
            plugin.machOffset = num(sOff.text, 0); plugin.trackDist = num(sTD.text, 5); plugin.trackSecs = num(sTS.text, 0);
            plugin.qTol = num(sQ.text, 2); plugin.streamInterval = Math.max(1, num(sStr.text, 10)); plugin.advDist = num(sAdvD.text, 100);
            plugin.machineId = sMid.text.trim();
            plugin.autoPickLine = sAuto.checked; plugin.alarmSound = sSnd.checked; plugin.csvLog = sCsv.checked; plugin.showTrail = sTr.checked;
            var layersChanged = (plugin.preplotName !== sPre.text.trim() || plugin.stationField !== sStnF.text.trim() || plugin.lineField !== sLnF.text.trim()
                                 || plugin.advLayerName !== sAdvL.text.trim() || plugin.advField !== sAdvF.text.trim());
            plugin.preplotName = sPre.text.trim(); plugin.stationField = sStnF.text.trim(); plugin.lineField = sLnF.text.trim();
            plugin.advLayerName = sAdvL.text.trim(); plugin.advField = sAdvF.text.trim();
            plugin.trackLayerName = sTrkL.text.trim() !== "" ? sTrkL.text.trim() : "NM_TrackPts";
            plugin.marksLayerName = sMkL.text.trim() !== "" ? sMkL.text.trim() : "NM_Marks";
            plugin.markerSym = plugin.symIds[sMkSym.currentIndex]; plugin.markerCol = plugin.colNames[sMkCol.currentIndex];
            plugin.markerSize = plugin.sizePx[sMkSize.currentIndex]; plugin.bearLen = plugin.lenM[sBearLen.currentIndex];
            plugin.lineStyle = sLineSt.currentIndex === 1 ? "Dashed" : "Solid"; plugin.lineCol = plugin.lineColNames[sLineCol.currentIndex];
            markerLayer.update(); symCv.requestPaint(); lineCv.requestPaint();
            plugin.saveSettings();
            if (layersChanged) { plugin.loadedOnce = false; plugin.startLoad(); }
            cfgPopup.close();
          } }
      }
    }
  }

  Component.onCompleted: {
    findQfScreens();
    initStore();
    loadSettings();
    initSounds();
    iface.addItemToPluginsToolbar(launcher);
  }
  Component.onDestruction: { try { flushTrack(); } catch (e) {} }
}
